import React, { useState } from "react";
import "./App.css";
import { BrowserRouter } from "react-router-dom";
import Router from "./routes/router";
import Navbar from "./components/navbar/Navbar";
import Footer from "./components/footer/Footer";
import ScrollToTop from "./utils/scrollToTop";
import Chat from "./components/chatbot/chat";
import ChatBot from "./components/chatbotkit/ChatBot";
import Whatsapp from "./components/whatsapp/whatsapp";
import { BsFillChatDotsFill } from "react-icons/bs";
import { IoCloseCircle } from "react-icons/io5";

function App() {
  const [openChatBot, seOpenChatBot] = useState(false);

  const openChatBotHandler = () => {
    seOpenChatBot(true);
  };

  const closeChatBotHandler = () => {
    seOpenChatBot(false);
  };

  return (
    <BrowserRouter>
      <Whatsapp />
      {openChatBot ? (
        <IoCloseCircle
          className="chat-icon"
          size={55}
          onClick={closeChatBotHandler}
        />
      ) : (
        ""
      )}
      {!openChatBot ? (
        <BsFillChatDotsFill
          className="chat-icon"
          size={45}
          onClick={openChatBotHandler}
        />
      ) : (
        ""
      )}
      {/* <Chat /> */}
      {openChatBot ? <ChatBot /> : ""}
      <ScrollToTop />
      <Navbar />
      <Router />
      <Footer />
    </BrowserRouter>
  );
}

export default App;
