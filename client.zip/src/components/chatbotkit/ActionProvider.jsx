import processToGpt from "./gpt";

class ActionProvider {
  constructor(createChatBotMessage, setStateFunc) {
    this.createChatBotMessage = createChatBotMessage;
    this.setState = setStateFunc;
  }

  greet = () => {
    const message = this.createChatBotMessage("Hello customer.");
    this.addMessageToState(message);
  };

  intro = () => {
    const message = this.createChatBotMessage(
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius repellat, dicta at laboriosam,"
    );
    this.addMessageToState(message);
  };

  delivery = () => {
    const message = this.createChatBotMessage(
      "After stiching work is done we deliver within 3 4 business days"
    );
    this.addMessageToState(message);
  };

  refund = () => {
    const message = this.createChatBotMessage(
      "Our return policy allows you to return unworn and unwashed items within 30 days of purchase. Please visit our Returns page for more information."
    );
    this.addMessageToState(message);
  };

  shipping = () => {
    const message = this.createChatBotMessage(
      "Yes, we offer free shipping on all orders over $50."
    );
    this.addMessageToState(message);
  };

  weddingDresses = () => {
    const message = this.createChatBotMessage(
      "Yes, we offer free shipping on all orders over $50."
    );
    this.addMessageToState(message);
  };

  sizes = () => {
    const message = this.createChatBotMessage(
      "We offer a wide range of sizes, from XS to XXL."
    );
    this.addMessageToState(message);
  };

  discount = () => {
    const message = this.createChatBotMessage(
      "We currently have a summer sale with up to 50% off on select items."
    );
    this.addMessageToState(message);
  };

  trackOrder = () => {
    const message = this.createChatBotMessage(
      "Yes, you can track your order by visiting the Order Tracking page and entering your order number."
    );
    this.addMessageToState(message);
  };

  paymentMethod = () => {
    const message = this.createChatBotMessage(
      "We accept Visa, MasterCard, American Express, and PayPal."
    );
    this.addMessageToState(message);
  };

  sourced = () => {
    const message = this.createChatBotMessage(
      "Yes, we prioritize ethical sourcing and work with suppliers who adhere to fair labor practices."
    );
    this.addMessageToState(message);
  };

  regularVsSlim = () => {
    const message = this.createChatBotMessage(
      "Slim fit is more tailored and closer to the body, while regular fit offers a more relaxed and comfortable fit."
    );
    this.addMessageToState(message);
  };

  cancelOrder = () => {
    const message = this.createChatBotMessage(
      "Yes, you can cancel your order within 24 hours of placing it. Please contact our customer support team for assistance."
    );
    this.addMessageToState(message);
  };

  sizeGuider = () => {
    const message = this.createChatBotMessage(
      "Yes, we have a size guide available on our website. It provides measurements for each size to help you choose the right fit."
    );
    this.addMessageToState(message);
  };

  exchange = () => {
    const message = this.createChatBotMessage(
      "Yes, we offer exchanges for different sizes or colors. Please review our Exchange Policy for more details."
    );
    this.addMessageToState(message);
  };

  promotion = () => {
    const message = this.createChatBotMessage(
      "Yes, new customers can enjoy a 10% discount on their first order. Use the code NEW10 at checkout."
    );
    this.addMessageToState(message);
  };

  gpt = async (msg) => {
    const resMessage = await processToGpt(msg);
    console.log(resMessage);
    const message = this.createChatBotMessage(resMessage);
    this.addMessageToState(resMessage);
  };

  addMessageToState = (message) => {
    this.setState((prevState) => ({
      ...prevState,
      messages: [...prevState.messages, message],
    }));
  };
}

export default ActionProvider;
