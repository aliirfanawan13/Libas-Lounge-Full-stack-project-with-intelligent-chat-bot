class MessageParser {
  constructor(actionProvider) {
    this.actionProvider = actionProvider;
  }

  parse(message) {
    const lowercase = message.toLowerCase();

    if (lowercase.includes("hello") || lowercase.includes("hi")) {
      this.actionProvider.greet();
    }

    if (
      lowercase.includes("who are you") ||
      lowercase.includes("what is libas")
    ) {
      this.actionProvider.intro();
    }

    if (
      lowercase.includes("how much time for delivery") ||
      lowercase.includes("delivery time")
    ) {
      this.actionProvider.delivery();
    }
    if (
      lowercase.includes("what's your return policy?") ||
      lowercase.includes("whats your return policy") ||
      lowercase.includes("return policy")
    ) {
      this.actionProvider.refund();
    }
    if (
      lowercase.includes("refund") ||
      lowercase.includes("does libas have any refund policey")
    ) {
      this.actionProvider.refund();
    }
    if (
      lowercase.includes("free shipping") ||
      lowercase.includes("do you offer free shipping?") ||
      lowercase.includes("do you offer free shipping") ||
      lowercase.includes("you offer free shipping?")
    ) {
      this.actionProvider.shipping();
    }

    if (
      lowercase.includes("what sizes do you offer?") ||
      lowercase.includes("what sizes do you offer") ||
      lowercase.includes("sizes you offer?")
    ) {
      this.actionProvider.sizes();
    }

    if (
      lowercase.includes("are there any discounts available?") ||
      lowercase.includes("are there any discounts available?") ||
      lowercase.includes("any discounts available")
    ) {
      this.actionProvider.discount();
    }

    if (
      lowercase.includes("can I track my order?") ||
      lowercase.includes("can I track my order") ||
      lowercase.includes("track my order") ||
      lowercase.includes("how to track my order") ||
      lowercase.includes("how i can my order")
    ) {
      this.actionProvider.trackOrder();
    }

    if (
      lowercase.includes("what payment methods do you accept?") ||
      lowercase.includes("what payment methods do you accept") ||
      lowercase.includes("which payment method do you accept?") ||
      lowercase.includes("which payment methods do you accept") ||
      lowercase.includes("payment methods")
    ) {
      this.actionProvider.paymentMethod();
    }

    if (
      lowercase.includes("are your products ethically sourced?") ||
      lowercase.includes("are your products ethically sourced") ||
      lowercase.includes("your's products ethically sourced") ||
      lowercase.includes("yours payment methods do you accept")
    ) {
      this.actionProvider.sourced();
    }

    if (
      lowercase.includes(
        "what's the difference between slim fit and regular fit?"
      ) ||
      lowercase.includes(
        "what's the difference between slim fit and regular fit"
      ) ||
      lowercase.includes(
        "what is the difference between slim fit and regular fit?"
      ) ||
      lowercase.includes(
        "what is the difference between slim fit and regular fit"
      ) ||
      lowercase.includes("difference between slim fit and regular fit")
    ) {
      this.actionProvider.regularVsSlim();
    }

    if (
      lowercase.includes("can I cancel my order?") ||
      lowercase.includes("can I cancel my order") ||
      lowercase.includes("how to cancel my order?") ||
      lowercase.includes("how to cancel my order")
    ) {
      this.actionProvider.cancel();
    }

    if (
      lowercase.includes("do you have a size guide?") ||
      lowercase.includes("do you have a size guide") ||
      lowercase.includes("you have a size guide")
    ) {
      this.actionProvider.sizeGuider();
    }

    if (
      lowercase.includes("can I exchange an item?") ||
      lowercase.includes("can I exchange an item") ||
      lowercase.includes("do you have exchange policey?") ||
      lowercase.includes("do you have exchange policey")
    ) {
      this.actionProvider.exchange();
    }

    if (
      lowercase.includes("do you have any promotions for new customers?") ||
      lowercase.includes("do you have any promotions for new customers") ||
      lowercase.includes("do you have any promotion?") ||
      lowercase.includes("do you have any promotion") ||
      lowercase.includes("do you offer promotion")
    ) {
      this.actionProvider.promotion();
    } else {
      this.actionProvider.gpt(message);
    }
  }
}

export default MessageParser;
