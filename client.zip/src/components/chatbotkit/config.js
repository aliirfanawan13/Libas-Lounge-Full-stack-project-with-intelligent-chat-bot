import React from "react";
import { createChatBotMessage } from "react-chatbot-kit";

const config = {
  botName: "Libas Bot",
  initialMessages: [createChatBotMessage(`Hello. How can i help you?`)],
  customStyles: {
    botMessageBox: {
      backgroundColor: "#5d1b5b",
    },
    chatButton: {
      backgroundColor: "#e1af4b",
    },
  },
  state: {
    gpt: "",
  },
};

export default config;
