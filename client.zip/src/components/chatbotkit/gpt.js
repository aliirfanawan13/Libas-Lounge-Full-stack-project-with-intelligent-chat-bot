export default async function callGpt(msg) {
  const result = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization:
        "Bearer " + "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",
      "Content-Type": "application/json",
    },
    body: msg,
  })
    .then((data) => {
      return data.json();
    })
    .then((data) => {
      console.log(data);
      return data;
    });
  return result;
}
