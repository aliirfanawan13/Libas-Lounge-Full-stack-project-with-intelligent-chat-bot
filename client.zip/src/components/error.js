import React from "react";

function Error({ text }) {
  return <div className="p-1 text-danger">{text}</div>;
}

export default Error;
