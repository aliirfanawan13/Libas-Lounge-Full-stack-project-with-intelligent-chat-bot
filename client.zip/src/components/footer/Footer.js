import React from "react";
import "./Footer.css";
import logo from "../../assets/images/logo_trans.png";
import { Link } from "react-router-dom";
import { AiFillInstagram, AiOutlineTwitter } from "react-icons/ai";
import { FaFacebookF } from "react-icons/fa";

const Footer = () => {
  return (
    <div className="footer py-md-5 py-3">
      <div className="container">
        <div className="d-flex flex-column flex-md-row justify-content-between">
          <div className="f-logo-container">
            <img src={logo} alt="libas" className="footer-logo" />
            <p className="mt-2">Libaas Lounge officials</p>
            <p className="mt-2">Libaas@company.com</p>
            <p className="mt-2">0308-8477797</p>
          </div>
          <div className="footer-links">
            <h6 className="fw-bold mb-4 mt-3 mt-md-0">Shopping & Categories</h6>
            <Link to="/bridal" className="foot-link link">
              <p>Bridal</p>
            </Link>
            <Link to="/formal" className="foot-link link">
              <p>Formals</p>
            </Link>
          </div>
          <div className="footer-links">
            <h6 className="fw-bold mb-4 mt-3 mt-md-0">Useful Links</h6>
            <Link to="/" className="foot-link link">
              <p>Home</p>
            </Link>
            <Link to="/contact" className="foot-link link">
              <p>Contact Us</p>
            </Link>
            <Link to="/about" className="foot-link link">
              <p>About Us</p>
            </Link>
          </div>
          <div className="footer-links">
            <h6 className="fw-bold mb-4 mt-3 mt-md-0">Help & Information</h6>
            <Link to="/about" className="foot-link link">
              <p>Faqs</p>
            </Link>
          </div>
        </div>
        <hr className="footer-hr my-5" />
        <div className="social-links">
          <a
            href="https://www.instagram.com/libasloungeofficial/?igshid=MzRlODBiNWFlZA%3D%3D"
            target="_blank"
          >
            <AiFillInstagram size={24} className="social-link" />
          </a>
          <a href="https://twitter.com/home" target="_blank">
            <AiOutlineTwitter size={24} className="social-link" />
          </a>
          <a href="https://www.facebook.com/" target="_blank">
            <FaFacebookF size={24} className="social-link" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default Footer;
