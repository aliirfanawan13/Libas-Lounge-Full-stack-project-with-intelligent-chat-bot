import React from "react";
import GoogleMapReact from "google-map-react";

const GoogleMaps = ({ latitude, longitude }) => {
  const renderMarkers = (map, maps) => {
    let marker = new maps.Marker({
      position: { lat: 29.400360000000035, lng: 71.66530000000006 },
      map,
      title: "Libas lounge!",
    });
    return marker;
  };

  return (
    <div style={{ height: "90vh", width: "100%" }}>
      <GoogleMapReact
        bootstrapURLKeys={{ key: "AIzaSyBL4JbKL4SotWhSAnoYflXy9fnHrmT52Lg" }}
        defaultCenter={{ lat: 29.400360000000035, lng: 71.66530000000006 }}
        defaultZoom={15}
        yesIWantToUseGoogleMapApiInternals
        onGoogleApiLoaded={({ map, maps }) => renderMarkers(map, maps)}
      ></GoogleMapReact>
    </div>
  );
};

export default GoogleMaps;
