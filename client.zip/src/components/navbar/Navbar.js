import React from "react";
import "./Navbar.css";
import logo from "../../assets/images/logo_trans.png";
import { Link } from "react-router-dom";
import { BsCartCheck, BsBookmarkHeart } from "react-icons/bs";
import { RxHamburgerMenu } from "react-icons/rx";

const Navbar = () => {
  return (
    <>
      {" "}
      <div className="navbar">
        <div className="container">
          <div className="logo">
            <Link to="/" className="nav_link link">
              <img src={logo} alt="" className="logo" />
            </Link>
          </div>
          <div className="nav_links">
            <Link to="/" className="nav_link link">
              Home
            </Link>
            <Link to="/bridal" className="nav_link link">
              Bridal
            </Link>
            <Link to="/formal" className="nav_link link">
              Formals
            </Link>
            <Link to="/about" className="nav_link link">
              About
            </Link>
            <Link to="/contact" className="nav_link link">
              Contact
            </Link>
          </div>

          <div>
            <Link to="/wish-list" className="link">
              <BsBookmarkHeart size={26} className="nav_cart" />
            </Link>
            <Link to="/cart" className="ms-3 link">
              <BsCartCheck size={26} className="nav_cart" />
            </Link>
          </div>

          <RxHamburgerMenu
            size={26}
            className="hamburger_menu"
            data-bs-toggle="offcanvas"
            data-bs-target="#offcanvasWithBothOptions"
            aria-controls="offcanvasWithBothOptions"
          />
        </div>
      </div>
      <div
        className="offcanvas offcanvas-start"
        data-bs-scroll="true"
        tabindex="-1"
        id="offcanvasWithBothOptions"
        aria-labelledby="offcanvasWithBothOptionsLabel"
      >
        <div class="offcanvas-header">
          <h5 class="offcanvas-title" id="offcanvasWithBothOptionsLabel"></h5>
          <button
            type="button"
            class="btn-close"
            data-bs-dismiss="offcanvas"
            aria-label="Close"
          ></button>
        </div>
        <div class="offcanvas-body">
          <div className="off-can-links">
            <Link to="/" className="nav_link link off-can-link ">
              <p data-bs-dismiss="offcanvas">Home</p>
            </Link>
            <Link to="/bridal" className="nav_link link off-can-link">
              <p data-bs-dismiss="offcanvas">Bridal</p>
            </Link>
            <Link to="/formal" className="nav_link link off-can-link">
              <p data-bs-dismiss="offcanvas">Formals</p>
            </Link>
            <Link to="/about" className="nav_link link off-can-link">
              <p data-bs-dismiss="offcanvas"> About</p>
            </Link>
            <Link to="/contact" className="nav_link link off-can-link">
              <p data-bs-dismiss="offcanvas">Contact</p>
            </Link>
            <Link to="/cart" className="nav_link link off-can-link">
              <BsCartCheck
                size={26}
                className="off-can-cart"
                data-bs-dismiss="offcanvas"
              />
            </Link>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;
