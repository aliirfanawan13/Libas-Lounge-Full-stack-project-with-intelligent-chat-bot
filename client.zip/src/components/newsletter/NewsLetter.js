import React from "react";
import "./NewsLetter.css";
import { Input, Button } from "reactstrap";
import "./NewsLetter.css";

const NewsLetter = () => {
  return (
    <div className="my-5 newsletter">
      <div className="row">
        <div className="col col-md-7">
          <h1 className="fw-bold">Subscribe To Our Newsletter</h1>
          <div className="d-flex flex-column">
            <Input
              type="text"
              id="basicpill-name-input1"
              className="form-control news-input w-75 my-4"
              placeholder="Your Name"
              name="name"
            />
            <Input
              type="email"
              id="basicpill-email-input1"
              className="form-control news-input w-75"
              placeholder="Your Email"
              name="email"
            />
            <Button className="news-btn w-25 mt-4">Send</Button>
          </div>
        </div>
        <div className="col col-md-5">
          <div className="d-flex justify-content-between news-parent">
            <div className="d-flex flex-column">
              <div className="mb-4">
                <h6>Store Location:</h6>
                <p>23 street a b c</p>
              </div>
              <div className="mb-4">
                <h6>Phone:</h6>
                <p>010-020-0340</p>
              </div>
            </div>
            <div className="d-flex flex-column">
              <div className="mb-4">
                <h6>Work Hours:</h6>
                <p>07:30 AM - 9:30 PM</p>
                <p>Daily</p>
              </div>
              <div className="mb-4">
                <h6>Email:</h6>
                <p>MKHAN@company.com</p>
              </div>
              <div className="mb-4">
                <h6>Social Media:</h6>
                <p>Facebook, Linkedin</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewsLetter;
