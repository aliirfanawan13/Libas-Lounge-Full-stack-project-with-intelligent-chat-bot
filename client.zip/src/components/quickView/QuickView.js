import React, { useState } from "react";
import "./QuickView.css";
import { useDispatch, useSelector } from "react-redux";
import { addCart } from "../../redux/thunks/cart";
import { useNavigate } from "react-router-dom";
import sizeGuide from "../../assets/images/size-guide.webp";

// Import Swiper styles
import "swiper/css";

const QuickView = ({ product }) => {
  const navigate = useNavigate();
  const [quantity, setQuantity] = useState(1);
  const [colorIndex, setColorIndex] = useState(0);
  const [sizeIndex, setSizeIndex] = useState(0);
  const dispatch = useDispatch();

  const { loading } = useSelector((state) => state.cart);

  const addtoCart = (product) => {
    dispatch(
      addCart({
        pro: {
          color: product.colors?.[colorIndex].color,
          size: sizeIndex,
          name: product.name,
          quantity: Number(quantity),
          id: product.id,
          price: product.price,
          attachments: product?.attachments?.[0],
        },
        navigate,
      })
    );
  };

  return (
    <div className="container">
      <div
        className="row
       "
      >
        <div className="col col-12 col-md-6">
          <div
            id="carouselExampleControls"
            class="carousel slide"
            data-bs-ride="carousel"
          >
            <div class="carousel-inner">
              {product.attachments.map((image, index) => {
                return (
                  <div
                    class="carousel-item img-container active img-container-details"
                    style={{ backgroundImage: { image } }}
                  >
                    <img src={image} class="d-block w-100 " alt="..." />
                  </div>
                );
              })}
            </div>
            <button
              class="carousel-control-prev"
              type="button"
              data-bs-target="#carouselExampleControls"
              data-bs-slide="prev"
            >
              <span
                class="carousel-control-prev-icon"
                aria-hidden="true"
              ></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button
              class="carousel-control-next"
              type="button"
              data-bs-target="#carouselExampleControls"
              data-bs-slide="next"
            >
              <span
                class="carousel-control-next-icon"
                aria-hidden="true"
              ></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>
        </div>
        <div className="col col-12 col-md-6 px-3">
          <h3>{product?.name}</h3>
          <h4 className="price-title my-3">PKR {product?.price}</h4>
          <p>{product?.description}</p>
          <hr className="my-4" />
          <div className="d-flex flex-column flex-md-row justify-content-between">
            <div className="d-flex">
              {product.colors.map((color, i) => {
                return (
                  <div className="d-flex flex-column align-items-center">
                    <div
                      className="dot"
                      style={{ backgroundColor: `${color?.colorCode}` }}
                      onClick={() => setColorIndex(i)}
                    ></div>
                    {colorIndex == i ? (
                      <small
                        className="mt-1 align-self-start"
                        style={{ fontSize: "12px" }}
                      >
                        {color?.color}
                      </small>
                    ) : (
                      ""
                    )}
                  </div>
                );
              })}
            </div>
            <div className="d-flex">
              {product.sizes.map((size) => {
                return (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="flexRadioDefault"
                      id="flexRadioDefault1"
                      onChange={() => setSizeIndex(size?.size)}
                    />
                    <label class="form-check-label me-2">{size?.size}</label>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="d-flex justify-content-between mt-4 mb-2">
            <div className="d-flex justify-content-between align-items-center set-quantity px-3">
              {quantity > 1 ? (
                <p
                  className="minus text-muted"
                  onClick={() => setQuantity((quan) => quan - 1)}
                >
                  -
                </p>
              ) : (
                <p className="minus text-muted">-</p>
              )}
              <p>{quantity}</p>
              <p
                className="plus text-muted"
                onClick={() => setQuantity((quan) => quan + 1)}
              >
                +
              </p>
            </div>
            <div className="add-cart-btn">
              {loading ? (
                <button className="add-to-cart-btn">Loading...</button>
              ) : (
                <button
                  className="add-to-cart-btn"
                  onClick={() => addtoCart(product)}
                >
                  Add To Cart
                </button>
              )}
            </div>
          </div>
          <hr className="mt-4" />
          <div className="mt-3">
            <div className="mb-3">
              <button
                className="size_guide_btn"
                data-bs-toggle="modal"
                data-bs-target="#exampleModal"
              >
                Size Guide
              </button>
            </div>
            <div className="d-flex my-2">
              <h6 className="fw-bold ">
                SKU <span className="me-4">:</span>
              </h6>
              <p className="text-muted">{product?.id?.substring(0, 8)}</p>
            </div>
            <div className="d-flex my-2">
              <h6 className="fw-bold ">
                Category <span className="me-4">:</span>
              </h6>
              <p className="text-muted">{product?.category}</p>
            </div>
            <div className="d-flex my-2">
              <h6 className="fw-bold ">
                Tags <span className="me-4">:</span>
              </h6>
              <p className="text-muted">{product?.tags}</p>
            </div>
          </div>
        </div>
      </div>
      <div
        class="modal fade"
        id="exampleModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h1 class="modal-title fs-5" id="exampleModalLabel">
                Size Guide
              </h1>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
              <img src={sizeGuide} alt="" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuickView;
