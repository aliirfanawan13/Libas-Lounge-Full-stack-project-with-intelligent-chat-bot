import React from "react";
import SingleCard from "./SingleCard";

const CardsList = ({data,search}) => {
  return (
    <div className="row gx-5 text-center">
      {data.filter((prod => {
        return search?.toLocaleLowerCase() == ""  ? prod : prod?.name?.toLowerCase().includes(search.toLocaleLowerCase())
      })).map(product => {
        return (
          <div className="col col-12 col-md-6 col-lg-4 mb-4 mb-md-3">
            <SingleCard product={product} />
          </div>)})}
    </div>
  );
};

export default CardsList;
