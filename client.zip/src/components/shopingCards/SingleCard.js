import React from "react";
import "./SingleCard.css";
import img1 from "../../assets/images/formal5.png";
import { Link, link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { addWishlist } from "../../redux/thunks/wishlist";
import { addCart } from "../../redux/thunks/cart";

import {
  AiOutlineEye,
  AiOutlineHeart,
  AiFillHeart,
  AiOutlineShoppingCart,
} from "react-icons/ai";

const SingleCard = ({ product }) => {
  const dispatch = useDispatch();
  return (
    <div className="mb-5">
      <div class="card single-card">
        <div className="img-container">
          <img src={product?.attachments?.[0]} />
        </div>
        <div class="card-content">
          <p class="card-category py-2">
            <div className="d-flex justify-content-around">
              <Link
                to="/product-details"
                className="link"
                state={{ product: product }}
              >
                <AiOutlineEye
                  className="circle-icon"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  title="Quick Shop"
                />
              </Link>
              <AiOutlineHeart
                className="circle-icon"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                title="Add to wishlist"
                onClick={() => dispatch(addWishlist(product))}
              />
              {/* <AiOutlineShoppingCart
                  className="circle-icon"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                title="Add to cart"
                onClick={() => dispatch(addCart(product))}
                /> */}
            </div>
          </p>
        </div>
      </div>
      <p className="my-2 card-title">{product?.name}</p>
      <p className="card-price">PKR {product?.price}</p>
    </div>
  );
};

export default SingleCard;
