import React from "react";
import "./whatsapp.css";
import { RiWhatsappFill } from "react-icons/ri";

const whatsapp = () => {
  return (
    <div className="whatsapp">
      <a href="https://api.whatsapp.com/send?phone=03487171551" target="_blank">
        <RiWhatsappFill size={50} className="whats-icon" />
      </a>
    </div>
  );
};

export default whatsapp;
