import React from "react";
import "./About.css";
import logo from "../../assets/images/logo.jpg";
import { BsFillQuestionCircleFill } from "react-icons/bs";
import { TfiTruck } from "react-icons/tfi";
import { HiArrowPathRoundedSquare } from "react-icons/hi2";

const About = () => {
  return (
    <div className="container pt-5">
      <div className="row mx-auto">
        <div className="col col-12 col-md-5">
          <img src={logo} alt="logo" style={{ maxHeight: "500px" }} />
        </div>
        <div className="col col-12 col-md-5 pt-3 pt-md-5">
          <h2>About Libas</h2>
          <p className="text-muted my-3">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius
            repellat, dicta at laboriosam, nemo exercitationem itaque eveniet
            architecto cumque, deleniti commodi molestias repellendus quos sequi
            hic fugiat asperiores illum. Atque, in, fuga excepturi corrupti
            error corporis aliquam unde nostrum quas.
          </p>
          <p className="text-muted mt-2">
            Accusantium dolor ratione maiores est deleniti nihil? Dignissimos
            est, sunt nulla illum autem in, quibusdam cumque recusandae,
            laudantium minima repellendus.
          </p>
        </div>
      </div>
      <hr />
      <div className="row my-5">
        <div className="col col-md-4 d-flex">
          <div className="d-flex flex-column">
            <h5>
              <span>
                <TfiTruck size={30} className="about-icons" />
              </span>
              FREE SHIPPING
            </h5>
            <p className="mt-2">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus
              at iaculis quam. Integer accumsan tincidunt fringilla.
            </p>
          </div>
        </div>
        <div className="col col-md-4 d-flex">
          <div className="d-flex flex-column">
            <h5>
              <span>
                <HiArrowPathRoundedSquare size={30} className="about-icons" />
              </span>
              FREE Return
            </h5>
            <p className="mt-2">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus
              at iaculis quam. Integer accumsan tincidunt fringilla.
            </p>
          </div>
        </div>
        <div className="col col-md-4 d-flex">
          <div className="d-flex flex-column">
            <h5>
              <span>
                <BsFillQuestionCircleFill size={30} className="about-icons" />
              </span>
              CUSTOMER SUPPORT
            </h5>
            <p className="mt-2">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus
              at iaculis quam. Integer accumsan tincidunt fringilla.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
