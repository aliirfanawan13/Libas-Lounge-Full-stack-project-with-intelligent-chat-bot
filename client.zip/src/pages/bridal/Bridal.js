import React, { useEffect, useState } from "react";
import "./Bridal.css";
import CardsList from "../../components/shopingCards/CardsList";
import { useDispatch, useSelector } from "react-redux";
import { getProducts } from "../../redux/thunks/product"
import Loader from "../../components/Loader"

const Bridal = () => {
  const [search, setSearch] = useState("")
  const [data, setData] = useState([]);
  const dispatch = useDispatch()
  const { loading, products } = useSelector((state) => state.products);
  useEffect(() => {
    dispatch(getProducts());
  }, []);

  useEffect(() => {
    const bridalDresses = products.filter(prod => prod?.category?.toLowerCase() == "bridal" )
    setData(bridalDresses);
  }, [products]);

  return (
    <div className="container my-5">
      <div className="my-5 text-center page-title">
        <h1>Bridal Dresses</h1>
      </div>

      <div className="d-flex justify-content-end mb-5">
        <div class="input-group mb-3" style={{width:'300px'}}>
          <input type="text" class="form-control" placeholder="Search products" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={(e) => setSearch(e.target.value)} />
          <span class="input-group-text" id="basic-addon2" style={{cursor:"pointer"}}>Search</span>
        </div>
      </div>
      
      {
        loading ? <div className="card-cont"><Loader/></div>: ""
      }
      
      {data?.length > 0 && !loading ? <CardsList data={data} search={search} /> : ""}
    </div>
  );
};

export default Bridal;
