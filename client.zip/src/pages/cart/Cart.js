import React, { useEffect, useState } from "react";
import "./Cart.css";
import { MdDelete } from "react-icons/md";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getCart, deleteCart, emptyCart } from "../../redux/thunks/cart";
import Loader from "../../components/Loader";
import { addOrder } from "../../redux/thunks/order";
import { getPromos } from "../../redux/thunks/promo";
//
import { Input } from "reactstrap";

const Cart = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [promoInput, setPromoInput] = useState("");
  const [instructions, setInstructions] = useState("");
  const [data, setData] = useState([]);
  const [discount, setDiscount] = useState(0);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { loading: cartLoading, cart } = useSelector((state) => state.cart);
  const { loading } = useSelector((state) => state.orders);
  const { promo } = useSelector((state) => state.promos);

  useEffect(() => {
    dispatch(getCart());
  }, []);

  useEffect(() => {
    setData(cart);
  }, [cart]);

  const calculateTotal = () => {
    let total = 0;
    data.map((pro) => (total = total + Number(pro.price) * pro?.quantity));
    return total;
  };

  const handlePromo = () => {
    dispatch(
      getPromos({
        promo: promoInput,
      })
    );
    setPromoInput("");
  };

  useEffect(() => {
    if (promo) {
      let deci = promo.percentage / 100;
      let disc = calculateTotal() * deci;
      setDiscount(disc);
    }
  }, [promo]);

  const createOrder = () => {
    dispatch(
      addOrder({
        values: {
          products: [...cart],
          name,
          email,
          phone,
          address,
          status: "active",
          totalAmmount: calculateTotal(),
          discount,
          instructions,
          promo,
        },
        navigate,
        dispatch,
        emptyCart,
      })
    );
  };

  return (
    <section class="h-100 h-custom" style={{ height: "100vh" }}>
      <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
          <div class="col-12">
            <div
              class="card card-registration card-registration-2"
              style={{ borderRadius: "15px" }}
            >
              <div class="card-body p-0">
                <div class="row g-0">
                  <div class="col-lg-8">
                    <div class="p-5">
                      <div class="d-flex justify-content-between align-items-center mb-5">
                        <h1 class="fw-bold mb-0 cart-title">Shopping Cart</h1>
                        {!cartLoading ? (
                          <h6 class="mb-0 text-muted">{data?.length} items</h6>
                        ) : (
                          ""
                        )}
                      </div>
                      <hr class="my-4" />
                      {cartLoading ? (
                        <Loader />
                      ) : (
                        <>
                          {data?.map((prod) => {
                            return (
                              <>
                                <div class="row mb-4 d-flex justify-content-between align-items-center">
                                  <div class="col-md-2 col-lg-2 col-xl-2">
                                    <img
                                      src={prod.attachments}
                                      class="img-fluid rounded-3"
                                      alt="Cotton T-shirt"
                                    />
                                  </div>
                                  <div class="col-md-3 col-lg-3 col-xl-3">
                                    <p class="text-black mb-0">{prod?.name}</p>
                                  </div>
                                  <div class="col-md-3 col-lg-3 col-xl-2 d-flex">
                                    <p>{prod?.category}</p>
                                  </div>
                                  <div class="col-md-3 col-lg-2 col-xl-2 offset-lg-1">
                                    <h6 class="mb-0">PKR {prod?.price}</h6>
                                  </div>
                                  <div class="col-md-1 col-lg-1 col-xl-1 text-end">
                                    <MdDelete
                                      size={20}
                                      style={{
                                        color: "red",
                                        cursor: "pointer",
                                      }}
                                      onClick={() =>
                                        dispatch(deleteCart(prod?.id))
                                      }
                                    />
                                  </div>
                                </div>
                                <hr class="my-4" />
                              </>
                            );
                          })}
                        </>
                      )}

                      {data.length > 0 ? (
                        <div className="row mx-auto">
                          <div className="col col-12 col-md-6">
                            <Input
                              type="text"
                              className="form-control mb-3"
                              id="basicpill-email-input2"
                              placeholder="Name"
                              name="email"
                              value={name}
                              onChange={(e) => setName(e.target.value)}
                            />
                          </div>
                          <div className="col col-12 col-md-6">
                            {" "}
                            <Input
                              type="text"
                              className="form-control mb-3"
                              id="basicpill-email-input2"
                              placeholder="Email"
                              name="email"
                              value={email}
                              onChange={(e) => setEmail(e.target.value)}
                            />
                          </div>
                          <div className="col col-12 col-md-6">
                            <Input
                              type="text"
                              className="form-control mb-3"
                              id="basicpill-email-input2"
                              placeholder="Phone"
                              value={phone}
                              onChange={(e) => setPhone(e.target.value)}
                            />
                          </div>
                          <div className="col col-12 col-md-6">
                            {" "}
                            <Input
                              type="text"
                              className="form-control mb-3"
                              id="basicpill-email-input2"
                              placeholder="Address"
                              value={address}
                              onChange={(e) => setAddress(e.target.value)}
                            />
                          </div>
                          <div className="col col-12">
                            <div>
                              <label
                                for="exampleFormControlTextarea1"
                                class="form-label"
                              >
                                Instructions
                              </label>
                              <textarea
                                class="form-control"
                                id="exampleFormControlTextarea1"
                                rows="3"
                                onChange={(e) =>
                                  setInstructions(e.target.value)
                                }
                              ></textarea>
                            </div>
                          </div>
                        </div>
                      ) : (
                        ""
                      )}

                      <div class="pt-5">
                        <h6 class="mb-0">
                          <Link to="/" class="link">
                            <i class="fas fa-long-arrow-alt-left"></i>Back to
                            shop
                          </Link>
                        </h6>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 bg-grey">
                    <div class="p-5">
                      <h3 class="fw-bold mb-5 mt-2 pt-1">Summary</h3>
                      <hr class="my-4" />

                      <div class="d-flex justify-content-between mb-4">
                        <h6 class="text-uppercase">items {data?.length} </h6>
                        <h6>PKR {calculateTotal()}</h6>
                      </div>

                      <h class="text-uppercase mb-3">Promo code</h>

                      <div class="mb-5">
                        <div class="form-outline">
                          <input
                            type="text"
                            id="form3Examplea2"
                            class="form-control form-control-lg"
                            onChange={(e) => setPromoInput(e.target.value)}
                          />
                          <p
                            className="mt-2 text-end"
                            style={{ color: "#e1af4b", cursor: "pointer" }}
                            onClick={handlePromo}
                          >
                            Apply Code
                          </p>
                        </div>
                      </div>

                      <div class="d-flex justify-content-between mb-4">
                        <h6 class="text-uppercase">Discount</h6>
                        <h6>PKR {discount}</h6>
                      </div>

                      <hr class="my-4" />

                      <div class="d-flex justify-content-between mb-5">
                        <h5 class="text-uppercase">Total price</h5>
                        <h5>PKR {calculateTotal() - discount}</h5>
                      </div>
                      {loading ? (
                        <button
                          type="button"
                          class="btn btn-block btn-lg cart-btn"
                          onClick={() => createOrder()}
                        >
                          Loading...
                        </button>
                      ) : (
                        <button
                          type="button"
                          class="btn btn-block btn-lg cart-btn"
                          onClick={() => createOrder()}
                        >
                          Place Order
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Cart;
