import React from "react";
import "./Contact.css";
import { Card, Col, Input, Label, Row, Button, CardBody } from "reactstrap";
import { Formik } from "formik";
import * as Yup from "yup";
import Error from "../../components/error";
import { useDispatch, useSelector } from "react-redux";
import {sendMessage} from "../../redux/thunks/messages"

const validationSchema = Yup.object().shape({
  name: Yup.string().required("Name is required."),
  email: Yup.string().email().required("Email is required."),
  subject: Yup.string().required("Subject is required."),
  message: Yup.string().required("Message is required."),
});

const Contact = () => {
  const dispatch = useDispatch()
  const { loading } = useSelector((state) => state.messages);
  return (
    <div className="contct-us">
      <Row className="d-flex justify-content-center align-items-cenetr my-5">
        <Col md="6">
          <Formik
            initialValues={{
              name: "",
              email: "",
              subject: "",
              message: "",
            }}
            onSubmit={(values, {resetForm}) => {
              dispatch(sendMessage(values))
              resetForm()
            }}
            validationSchema={validationSchema}
          >
            {({
              setFieldValue,
              handleChange,
              handleBlur,
              handleSubmit,
              values,
              touched,
              errors,
            }) => {
              return (
                <Card className="contact-card p-4">
                  <CardBody>
                    <h2 className="mb-5 text-center">Contact Us</h2>
                    <Row>
                      <Col md="6">
                        <div className="mb-3">
                          <Label for="basicpill-name-input1">Name</Label>
                          <Input
                            type="text"
                            className="form-control"
                            id="basicpill-name-input1"
                            placeholder="enter name"
                            name="name"
                            value={values.name}
                            onChange={handleChange}
                            onBlur={handleBlur}
                          />
                          {errors.name && touched.name && (
                            <Error text={errors.name} />
                          )}
                        </div>
                      </Col>
                      <Col md="6">
                        <div className="mb-3">
                          <Label for="basicpill-email-input1">Email</Label>
                          <Input
                            type="email"
                            pattern="[^ @]*@[^ @]*"
                            className="form-control"
                            id="basicpill-email-input2"
                            placeholder="Enter email"
                            name="email"
                            value={values.email}
                            onChange={handleChange}
                            onBlur={handleBlur}
                          />
                          {errors.email && touched.email && (
                            <Error text={errors.email} />
                          )}
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col md="12">
                        <div className="mb-3">
                          <Label for="basicpill-description-input1">
                            Subject
                          </Label>
                          <Input
                            type="text"
                            id="basicpill-subject-input1"
                            className="form-control"
                            placeholder="Enter your subject"
                            name="subject"
                            onChange={handleChange}
                            onBlur={handleBlur}
                            value={values.subject}
                          />
                          {errors.subject && touched.subject && (
                            <Error text={errors.subject} />
                          )}
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col md="12">
                        <div className="mb-3">
                          <Label for="basicpill-description-input1">
                            Message
                          </Label>
                          <textarea
                            id="basicpill-message-input1"
                            className="form-control"
                            rows="6"
                            placeholder="Enter your message"
                            name="message"
                            onChange={handleChange}
                            onBlur={handleBlur}
                            value={values.message}
                          />
                          {errors.message && touched.message && (
                            <Error text={errors.message} />
                          )}
                        </div>
                      </Col>
                    </Row>
                    <div className="m-2 text-center">
                      {loading ? (<Button
                        className="contact-btn"
                      >
                        Loading...
                      </Button>):(<Button
                        className="contact-btn"
                        onClick={() => {
                          handleSubmit();
                        }}
                      >
                        Submit
                      </Button>)}
                      
                    </div>
                  </CardBody>
                </Card>
              );
            }}
          </Formik>
        </Col>
      </Row>
    </div>
  );
};

export default Contact;
