import React, { useEffect, useState } from "react";
import bridal1 from "../../assets/images/a.webp";
import formal2 from "../../assets/images/formal1.png";
import "./Home.css";
import NewsLetter from "../../components/newsletter/NewsLetter";
import GoogleMaps from "../../components/googleMap/GoogleMap";
import SingleCard from "../../components/shopingCards/SingleCard";
import { Link } from "react-router-dom";
import { HiArrowLongRight } from "react-icons/hi2";
// 
import { useDispatch, useSelector } from "react-redux";
import { getProducts } from "../../redux/thunks/product"
import Loader from "../../components/Loader"

const Home = () => {
  const [bridal, setBridal] = useState([]);
  const [formal, setFormal] = useState([])
   const dispatch = useDispatch()
  const { loading, products } = useSelector((state) => state.products);
  useEffect(() => {
    dispatch(getProducts());
  }, []);

  useEffect(() => {
    const bridalDresses = products.filter(prod => prod?.category?.toLowerCase() == "bridal")
    const formalDresses = products.filter(prod => prod?.category?.toLowerCase() == "formal" )
    setFormal(formalDresses);
    setBridal(bridalDresses)
  }, [products]);

  return (
    <div className="mb-5 position-relative">
      <div class="container">
        <div className="text-center my-5 ">
          <h1 className="cat-title">Categories</h1>
        </div>
        <div class="row ">
          <div class="col-12 col-md-6 my-3 my-md-0 mx-auto">
            <div className="cat-img-cont">
              <img src={bridal1} alt="bridal" className="cat-img1 " />
            </div>
            <div className="text-over-img">
              <h1 className="fw-bold">Bridal Wear</h1>
              <p className="mb-3">Check out 2023's Bridal Collection</p>
              <button className="dicov-btn">Discover more</button>
            </div>
          </div>
          <div class="col-12 col-md-6 my-3 my-md-0 mx-auto">
            <img src={formal2} alt="bridal" className="cat-img1 " />
            <div className="text-over-img">
              <h1 className="fw-bold">Formal Wear</h1>
              <p className="mb-3">Check out 2023's Formal Collection</p>
              <button className="dicov-btn">Discover more</button>
            </div>
          </div>
        </div>

        <div>
          <hr className="mt-5" style={{ borderTop: "5px dotted #E1AF4B" }} />
          <div className="card-sec my-5">
            <h2 className="mb-0">Formal's Latest</h2>
            <p>
              Details to details is what makes Libaas different from the other
              stores.
            </p>
          </div>
          <div className="row gx-5 text-center">
            {formal?.map(product => {
              return (
                <div className="col col-12 col-md-6 col-lg-4">
                    <SingleCard product={product}/>
                </div>
              )
            })}
          </div>
          <Link to="/formal" className="link text-end">
            <p>
              View All
              <span className="ms-2">
                <HiArrowLongRight size={30} />
              </span>
            </p>
          </Link>
        </div>

        <div>
          <div className="card-sec my-5">
            <h2 className="mb-0">Bridal's Latest</h2>
            <p>
              Details to details is what makes Libaas different from the other
              stores.
            </p>
          </div>
          <div className="row gx-5 text-center">
            {bridal?.map(product => {
              return(
                <div className="col col-12 col-md-6 col-lg-4">
                    <SingleCard product={product}/>
                </div>
              )
            })}
          </div>
          <Link to="/bridal" className="link text-end">
            <p>
              View All
              <span className="ms-2 ">
                <HiArrowLongRight size={30} />
              </span>
            </p>
          </Link>
        </div>

        <hr style={{ borderTop: "5px dotted #E1AF4B" }} />
        <div className="map-title text-center my-5">
          <h2>Our Outlet</h2>
          <p>We deliver our products free door to door</p>
        </div>
        <GoogleMaps />
        <NewsLetter />
      </div>
    </div>
  );
};

export default Home;
