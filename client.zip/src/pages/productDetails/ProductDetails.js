import React from "react";
import QuickView from "../../components/quickView/QuickView";
import { useLocation } from "react-router-dom";

const ProductDetails = () => {
  const location = useLocation();
  const { product } = location.state;
  return (
    <div className="my-5">
      <QuickView product={product} />
    </div>
  );
};

export default ProductDetails;
