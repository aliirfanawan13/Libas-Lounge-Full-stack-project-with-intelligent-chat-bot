import React, { useEffect, useState } from "react";
import "./WishList.css";
import { MdDelete } from "react-icons/md";
import { Link } from "react-router-dom";
import img3 from "../../assets/images/e.webp";
import { useDispatch, useSelector } from "react-redux";
import { getWishlist, deleteWishlist } from "../../redux/thunks/wishlist";
import Loader from "../../components/Loader";

const WishList = () => {
  const [data, setData] = useState([]);
  const dispatch = useDispatch();
  const { loading, wishlist } = useSelector((state) => state.wishlist);

  useEffect(() => {
    dispatch(getWishlist());
  }, []);

  useEffect(() => {
    setData(wishlist);
  }, [wishlist]);

  return (
    <section class="h-100 h-custom">
      <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
          <div class="col-12">
            <div
              class="card card-registration card-registration-2"
              style={{ borderRadius: "15px" }}
            >
              <div class="card-body p-0">
                <div class="row g-0">
                  <div class="col-lg-10">
                    <div class="p-5">
                      <div class="d-flex justify-content-between align-items-center mb-5">
                        <h1 class="fw-bold mb-0 wish-title">Wishlist</h1>
                        {!loading ? (
                          <h6 class="mb-0 text-muted">{data?.length} Items</h6>
                        ) : (
                          ""
                        )}
                      </div>
                      <hr class="my-4" />
                      {data?.map((wish) => {
                        return (
                          <>
                            <div class="row mb-4 d-flex justify-content-between align-items-center">
                              <div class="col-md-1 col-lg-1 col-xl-1 text-end">
                                <MdDelete
                                  onClick={() =>
                                    dispatch(deleteWishlist(wish._id))
                                  }
                                  size={20}
                                  style={{ color: "red", cursor: "pointer" }}
                                />
                              </div>
                              <div class="col-md-2 col-lg-2 col-xl-2">
                                <img
                                  src={wish.attachments?.[0]}
                                  class="img-fluid rounded-3"
                                  alt="Cotton T-shirt"
                                />
                              </div>
                              <div class="col-md-3 col-lg-3 col-xl-3">
                                <p class="text-muted">{wish?.category}</p>
                                <p class="text-black mb-0">{wish?.name}</p>
                              </div>
                              <div class="col-md-3 col-lg-2 col-xl-2 offset-lg-1">
                                <h6 class="mb-0">{wish.price}</h6>
                              </div>
                              <div class="col-md-1 col-lg-2 col-xl-2 text-end">
                                <Link
                                  to="/product-details"
                                  state={{ product: wish }}
                                >
                                  <button className="wish-list-btn">
                                    Add to Cart
                                  </button>
                                </Link>
                              </div>
                            </div>
                            <hr class="my-4" />
                          </>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WishList;
