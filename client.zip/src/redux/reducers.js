import { combineReducers } from "redux";

import users from "./slices/userSlice";
import messages from "./slices/messageSlice";
import promos from "./slices/promoSlice";
import products from "./slices/productSlice";
import orders from "./slices/orderSlice";
import wishlist from "./slices/wishlistSlice";
import cart from "./slices/cartSlice";
import currency from "./slices/currencySlice";

export default combineReducers({
  users,
  messages,
  promos,
  products,
  orders,
  wishlist,
  cart,
  currency,
});
