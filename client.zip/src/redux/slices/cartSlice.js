import { createSlice } from "@reduxjs/toolkit";

import { deleteCart, getCart, addCart, emptyCart } from "../thunks/cart";

const initialState = {
  cart: [],
  loading: false,
  error: null,
  success: null,
};

const handlePending = (state, action) => {
  state.loading = true;
  state.error = initialState.error;
  state.success = initialState.success;
};
const handleRejected = (state, action) => {
  state.loading = false;
  state.error = action.payload;
};
const handleSuccess = (state, action) => {
  state.loading = false;
  state.success = action.payload;
};
const onGetCart = (state, action) => {
  state.cart = action.payload;
  state.loading = false;
};
const onDeleteCart = (state, action) => {
  state.cart = state.cart.filter((c) => c.id !== action.payload);
  state.loading = false;
};
const onEmptyCart = (state, action) => {
  state.cart = [];
  state.loading = false;
};

const onAddCart = (state, action) => {
  state.cart = action.payload;
  state.loading = false;
};

const slice = createSlice({
  name: "cart",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getCart.pending, handlePending)
      .addCase(getCart.fulfilled, onGetCart)
      .addCase(getCart.rejected, handleRejected)

      .addCase(deleteCart.pending, handlePending)
      .addCase(deleteCart.fulfilled, onDeleteCart)
      .addCase(deleteCart.rejected, handleRejected)

      .addCase(addCart.pending, handlePending)
      .addCase(addCart.fulfilled, onAddCart)
      .addCase(addCart.rejected, handleRejected)

      .addCase(emptyCart.pending, handlePending)
      .addCase(emptyCart.fulfilled, onEmptyCart)
      .addCase(emptyCart.rejected, handleRejected);
  },
});

export const {} = slice.actions;
export default slice.reducer;
