import { createSlice } from "@reduxjs/toolkit";
import { getCurrency, changeCurrency } from "../thunks/currency";

const initialState = {
  currencies: [],
  baseCurrency: "PKR",
  currentCurrency: "PKR",
  loading: false,
  error: null,
  success: null,
};

const handlePending = (state, action) => {
  state.loading = true;
  state.error = initialState.error;
  state.success = initialState.success;
};
const handleRejected = (state, action) => {
  state.loading = false;
  state.error = action.payload;
};
const handleSuccess = (state, action) => {
  state.loading = false;
  state.success = action.payload;
};
const onGetCurrency = (state, action) => {
  state.currencies = action.payload;
  state.loading = false;
};
const onChangeCurrency = (state, action) => {
  state.currentCurrency = action.payload;
  state.loading = false;
};

const slice = createSlice({
  name: "currency",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getCurrency.pending, handlePending)
      .addCase(getCurrency.fulfilled, onGetCurrency)
      .addCase(getCurrency.rejected, handleRejected)

      .addCase(changeCurrency.pending, handlePending)
      .addCase(changeCurrency.fulfilled, onChangeCurrency)
      .addCase(changeCurrency.rejected, handleRejected);
  },
});

export const {} = slice.actions;
export default slice.reducer;
