import { createSlice } from "@reduxjs/toolkit";

import { sendMessage } from "../thunks/messages";

const initialState = {
  messages: [],
  loading: false,
  error: null,
  success: null,
};

const handlePending = (state, action) => {
  state.loading = true;
  state.error = initialState.error;
  state.success = initialState.success;
};
const handleRejected = (state, action) => {
  state.loading = false;
  state.error = action.payload;
};
const handleSuccess = (state, action) => {
  state.loading = false;
  state.success = action.payload;
};
const onSendMessage = (state, action) => {
  state.messages = action.payload;
  state.loading = false;
};

const slice = createSlice({
  name: "messages",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(sendMessage.pending, handlePending)
      .addCase(sendMessage.fulfilled, onSendMessage)
      .addCase(sendMessage.rejected, handleRejected)

  },
});

export const {} = slice.actions;
export default slice.reducer;
