import { createSlice } from "@reduxjs/toolkit";

import { addOrder } from "../thunks/order";

const initialState = {
  orders: [],
  loading: false,
  error: null,
  success: null,
};

const handlePending = (state, action) => {
  state.loading = true;
  state.error = initialState.error;
  state.success = initialState.success;
};
const handleRejected = (state, action) => {
  state.loading = false;
  state.error = action.payload;
};
const handleSuccess = (state, action) => {
  state.loading = false;
  state.success = action.payload;
};

const onAddOrder = (state, action) => {
  state.loading = false;
};

const slice = createSlice({
  name: "orders",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(addOrder.pending, handlePending)
      .addCase(addOrder.fulfilled, onAddOrder)
      .addCase(addOrder.rejected, handleRejected)
  },
});

export const {} = slice.actions;
export default slice.reducer;
