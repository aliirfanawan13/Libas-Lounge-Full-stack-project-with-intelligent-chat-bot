import { createSlice } from "@reduxjs/toolkit";

import { getPromos } from "../thunks/promo";

const initialState = {
  promo: null,
  loading: false,
  error: null,
  success: null,
};

const handlePending = (state, action) => {
  state.loading = true;
  state.error = initialState.error;
  state.success = initialState.success;
};
const handleRejected = (state, action) => {
  state.loading = false;
  state.error = action.payload;
};
const handleSuccess = (state, action) => {
  state.loading = false;
  state.success = action.payload;
};
const onGetPromos = (state, action) => {
  state.promo = action.payload;
  state.loading = false;
};

const slice = createSlice({
  name: "promos",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getPromos.pending, handlePending)
      .addCase(getPromos.fulfilled, onGetPromos)
      .addCase(getPromos.rejected, handleRejected);
  },
});

export const {} = slice.actions;
export default slice.reducer;
