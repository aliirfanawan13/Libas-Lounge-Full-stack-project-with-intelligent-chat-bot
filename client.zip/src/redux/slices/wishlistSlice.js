import { createSlice } from "@reduxjs/toolkit";

import { deleteWishlist, getWishlist, addWishlist } from "../thunks/wishlist";

const initialState = {
  wishlist: [],
  loading: false,
  error: null,
  success: null,
};

const handlePending = (state, action) => {
  state.loading = true;
  state.error = initialState.error;
  state.success = initialState.success;
};
const handleRejected = (state, action) => {
  state.loading = false;
  state.error = action.payload;
};
const handleSuccess = (state, action) => {
  state.loading = false;
  state.success = action.payload;
};
const onGetWishlist = (state, action) => {
  state.wishlist = action.payload;
  state.loading = false;
};
const onDeleteWishlist = (state, action) => {
  state.wishlist = state.wishlist.filter((wish) => wish._id !== action.payload);
  state.loading = false;
};

const onAddWishlist = (state, action) => {
  state.wishlist = action.payload;
  state.loading = false;
};

const slice = createSlice({
  name: "wishlist",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getWishlist.pending, handlePending)
      .addCase(getWishlist.fulfilled, onGetWishlist)
      .addCase(getWishlist.rejected, handleRejected)

      .addCase(deleteWishlist.pending, handlePending)
      .addCase(deleteWishlist.fulfilled, onDeleteWishlist)
      .addCase(deleteWishlist.rejected, handleRejected)

      .addCase(addWishlist.pending, handlePending)
      .addCase(addWishlist.fulfilled, onAddWishlist)
      .addCase(addWishlist.rejected, handleRejected)
  },
});

export const {} = slice.actions;
export default slice.reducer;
