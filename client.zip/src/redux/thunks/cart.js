import { createAsyncThunk } from "@reduxjs/toolkit";
import Services from "../../services/services";

export const deleteCart = createAsyncThunk(
  "cart/deletCart",
  async (data, { rejectWithValue }) => {
    try {
      return data;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const getCart = createAsyncThunk(
  "cart/getCart",
  async (data, { rejectWithValue, getState }) => {
    const state = getState();
    const user = JSON.parse(localStorage.getItem("AppUser"));
    try {
      return state.cart.cart;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const emptyCart = createAsyncThunk(
  "cart/emptyCart",
  async (data, { rejectWithValue, getState }) => {
    const state = getState();
    const user = JSON.parse(localStorage.getItem("AppUser"));
    try {
      return;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const addCart = createAsyncThunk(
  "cart/addCart",
  async (data, { rejectWithValue, getState }) => {
    const state = getState();
    const user = JSON.parse(localStorage.getItem("AppUser"));
    try {
      let newCart = [...state.cart.cart, data?.pro];
      // if (user !== null) {
      //     const endpoint = "users/update";
      //     const user = await Services.updateDocument(endpoint, { data, _id: user?._id });
      //     return user.wishlist
      // } else {
      //     const wishdata = [...state.wishlist.wishlist, data]
      //     return wishdata
      // }
      data.navigate("/");
      return newCart;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);
