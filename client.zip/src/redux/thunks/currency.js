import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const getCurrency = createAsyncThunk(
  "currency/getCurrency",
  async (data, { rejectWithValue }) => {
    const endpoint =
      "https://v6.exchangerate-api.com/v6/760519113185957924205ed5/latest/USD";
    try {
      const res = await axios({
        method: "get",
        url: `${endpoint}`,
        headers: {
          "Content-Type": "application/json",
        },
      });
      console.log(res);
      return res.conversion_rates;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const changeCurrency = createAsyncThunk(
  "currency/changeCurrency",
  async (data, { rejectWithValue }) => {
    try {
      return data;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);
