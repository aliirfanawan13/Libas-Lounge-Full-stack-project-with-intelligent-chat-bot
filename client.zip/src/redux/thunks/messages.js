import { createAsyncThunk } from "@reduxjs/toolkit";
import Services from "../../services/services";

export const sendMessage = createAsyncThunk(
  "messages/getMessages",
  async (data, { rejectWithValue }) => {
    const endpoint = "message/add-new";
    console.log(data)
    try {
      const msg = await Services.addDocument(endpoint,data);
      return msg.msg;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);
