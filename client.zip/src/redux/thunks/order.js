import { createAsyncThunk } from "@reduxjs/toolkit";
import Services from "../../services/services";

export const addOrder = createAsyncThunk(
  "orders/addOrder",
  async (data, { rejectWithValue }) => {
    const endpoint = "orders/add-new";
    const promo = data.values.promo;
    try {
      const addorder = await Services.addDocument(endpoint, data.values);
      const updatePromo = {
        used: promo.used + 1,
        remaining: promo.remaining - 1,
        id: promo._id,
      };
      await Services.updateDocument("promo/update", updatePromo);
      data.dispatch(data.emptyCart());
      data.navigate("/");
      return;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);
