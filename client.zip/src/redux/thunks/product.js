import { createAsyncThunk } from "@reduxjs/toolkit";
import Services from "../../services/services";

export const deleteProduct = createAsyncThunk(
  "products/deleteProduct",
  async (data, { rejectWithValue }) => {
    const endpoint = "product/delete-by-id";
    try {
      const pro = await Services.deleteDocument(endpoint, data);
      return data;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const getProducts = createAsyncThunk(
  "products/getPrducts",
  async (data, { rejectWithValue }) => {
    const endpoint = "product/get-all";
    try {
      const products = await Services.getDocuments(endpoint);
      console.log(products.products);
      return products.products;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const updateProduct = createAsyncThunk(
  "products/updateProduct",
  async (data, { rejectWithValue }) => {
    console.log(data);
    const endpoint = "product/update";
    try {
      const updatedproduct = await Services.updateDocument(
        endpoint,
        data.values
      );
      data.navigate("/products");
      return updatedproduct.updatedproduct;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const addProduct = createAsyncThunk(
  "product/addProduct",
  async (data, { rejectWithValue }) => {
    const endpoint = "product/add-new";
    try {
      const product = await Services.addDocument(endpoint, { ...data.values });
      data.navigate("/products");
      return;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);
