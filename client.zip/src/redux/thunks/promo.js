import { createAsyncThunk } from "@reduxjs/toolkit";
import Services from "../../services/services";

export const getPromos = createAsyncThunk(
  "promos/getPromos",
  async (data, { rejectWithValue }) => {
    const endpoint = "promo/get-all";
    try {
      const prom = await Services.getDocuments(endpoint);
      let check = null;
      prom.prom.map((pro) => {
        if (pro.code === data.promo && pro.used <= pro.total) {
          check = pro;
        }
      });
      return check;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);
