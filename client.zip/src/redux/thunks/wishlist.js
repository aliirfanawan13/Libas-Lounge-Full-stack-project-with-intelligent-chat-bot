import { createAsyncThunk } from "@reduxjs/toolkit";
import Services from "../../services/services";

export const deleteWishlist = createAsyncThunk(
  "wishlist/deleteWishlist",
  async (data, { rejectWithValue }) => {
    const user = JSON.parse(localStorage.getItem("AppUser"));
    try {
      return data;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const getWishlist = createAsyncThunk(
  "wishlist/getWishlist",
    async (data, { rejectWithValue, getState }) => {
    const state = getState()
    const user = JSON.parse(localStorage.getItem("AppUser"));
    try {
       return state.wishlist.wishlist
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const addWishlist = createAsyncThunk(
  "wishlist/addWishlist",
    async (data, { rejectWithValue, getState }) => {
    const state = getState()
    const user = JSON.parse(localStorage.getItem("AppUser"));
      console.log(data)
      console.log(state)
      try {
      let newWishlist = [...state.wishlist.wishlist, data]
      return newWishlist
        // if (user !== null) {
        //     const endpoint = "users/update";
        //     const user = await Services.updateDocument(endpoint, { data, _id: user?._id });
        //     return user.wishlist
        // } else {
        //     const wishdata = [...state.wishlist.wishlist, data]
        //     return wishdata
        // }
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);
