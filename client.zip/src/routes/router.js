import React from "react";
// react router dom
import { Route, Routes } from "react-router-dom";
// pages
import Home from "../pages/home/Home";
import About from "../pages/about/About";
import Contact from "../pages/contact/Contact";
import Bridal from "../pages/bridal/Bridal";
import Formal from "../pages/formals/Formals";
import Cart from "../pages/cart/Cart";
import WishList from "../pages/wishlist/WishList";
import NotFound from "../utils/pageNotFound";
import ProductDetails from "../pages/productDetails/ProductDetails";

const Router = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/bridal" element={<Bridal />} />
      <Route path="/formal" element={<Formal />} />
      <Route path="/cart" element={<Cart />} />
      <Route path="/product-details" element={<ProductDetails />} />
      <Route path="/wish-list" element={<WishList />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default Router;
