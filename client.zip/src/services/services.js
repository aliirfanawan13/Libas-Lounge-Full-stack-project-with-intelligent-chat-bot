import axios from "axios";

const baseUrl = "http://localhost:5000/api";

const Services = {
  signIn: async (email, password) => {
    try {
      const res = await axios({
        method: "post",
        url: `${baseUrl}/user/auth`,
        data: {
          email,
          password,
        },
        headers: {
          "Content-Type": "application/json",
        },
      });
      return res.data;
    } catch (err) {
      throw new Error(err.message);
    }
  },

  signOut: async () => {
    try {
      return;
    } catch (err) {
      throw new Error(err.message);
    }
  },

  getDocuments: async (endpoint) => {
    try {
      const res = await axios({
        method: "get",
        url: `${baseUrl}/${endpoint}`,
        headers: {
          "Content-Type": "application/json",
        },
      });
      return res.data;
    } catch (err) {
      throw new Error(err.message);
    }
  },

  addDocument: async (endpoint, data) => {
    try {
      const res = await axios({
        method: "post",
        url: `${baseUrl}/${endpoint}`,
        data: {
          data,
        },
        headers: {
          "Content-Type": "application/json",
        },
      });
      return res.data;
    } catch (err) {
      throw new Error(err.message);
    }
  },

  updateDocument: async (endpoint, data) => {
    try {
      const res = await axios({
        method: "put",
        url: `${baseUrl}/${endpoint}`,
        data: { ...data },
        headers: {
          "Content-Type": "application/json",
        },
      });
      return res.data;
    } catch (err) {
      throw new Error(err.message);
    }
  },

  deleteDocument: async (endpoint, data) => {
    try {
      const res = await axios({
        method: "delete",
        url: `${baseUrl}/${endpoint}`,
        data: {
          id: data,
        },
        headers: {
          "Content-Type": "application/json",
        },
      });
      return res.data;
    } catch (err) {
      throw new Error(err.message);
    }
  },
};

export default Services;
