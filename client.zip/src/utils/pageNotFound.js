import React from "react";
import "./pageNotFound.css";
import { Link } from "react-router-dom";

const pageNotFound = () => {
  return (
    <div className="my-0 my-md-5">
      <section class="error-container">
        <span class="four">
          <span class="screen-reader-text">4</span>
        </span>
        <span class="zero">
          <span class="screen-reader-text">0</span>
        </span>
        <span class="four">
          <span class="screen-reader-text">4</span>
        </span>
      </section>
      <h1 className="text-center error-title">Page Not Found</h1>
      <div className="text-center">
        <div class="link-container mb-2 mb-md-5">
          <Link to="/" className="link ">
            Go To Home
          </Link>
        </div>
      </div>
    </div>
  );
};

export default pageNotFound;
