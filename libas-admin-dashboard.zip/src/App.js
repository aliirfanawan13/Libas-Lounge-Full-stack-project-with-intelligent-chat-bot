import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import Sidebar from "./components/sidebar/Sidebar";
import Topbar from "./components/topbar/Topbar";
import "./App.css";
import Home from "./pages/home/Home";
import { Route, BrowserRouter as Router, Routes } from "react-router-dom";
import ProtectedRoute from "./routes/ProtectedRoute";
import PublicRoute from "./routes/PublicRoute";

//users
import UserList from "./pages/users/userList/UserList";
import User from "./pages/users/user/User";
import NewUser from "./pages/users/newUser/NewUser";

// products
import ProductList from "./pages/products/productList/ProductList";
import Product from "./pages/products/product/Product";
import NewProduct from "./pages/products/newProduct/NewProduct";

// promo codes
import PromosList from "./pages/promos/PromoCodes";
import NewPromoCodes from "./pages/promos/CreatePromos";
import EditPromoCodes from "./pages/promos/EditPromos";

//messages list
import MessagesList from "./pages/message/MessagesList";
import MessagesDetails from "./pages/message/MessageDetails";

//orders
import OrdersList from "./pages/orders/OrdersList";
import OrderDetails from "./pages/orders/OrderDetails";

// Login
import Login from "./pages/auth/login/Login";

function App() {
  const user = JSON.parse(localStorage.getItem("User"));
  const { user: userr } = useSelector((state) => state.users);
  useEffect(() => {}, [userr]);

  return (
    <>
      <Router>
        {user ? <Topbar /> : ""}
        <div className="containerr">
          {user ? <Sidebar /> : ""}
          <Routes>
            <Route
              path="/"
              element={
                <ProtectedRoute user={user}>
                  <Home />
                </ProtectedRoute>
              }
            />
            ,
            <Route
              path="/users"
              element={
                <ProtectedRoute user={user}>
                  <UserList />
                </ProtectedRoute>
              }
            />
            ,
            <Route
              path="/user/:userId"
              element={
                <ProtectedRoute user={user}>
                  <User />
                </ProtectedRoute>
              }
            />
            ,
            <Route
              path="/newUser"
              element={
                <ProtectedRoute user={user}>
                  <NewUser />
                </ProtectedRoute>
              }
            />
            ,
            <Route
              path="/products"
              element={
                <ProtectedRoute user={user}>
                  <ProductList />
                </ProtectedRoute>
              }
            />
            ,
            <Route
              path="/product/:productId"
              element={
                <ProtectedRoute user={user}>
                  <Product />
                </ProtectedRoute>
              }
            />
            ,
            <Route
              path="/newproduct"
              element={
                <ProtectedRoute user={user}>
                  <NewProduct />
                </ProtectedRoute>
              }
            />
            ,
            <Route
              path="/orders"
              element={
                <ProtectedRoute user={user}>
                  <OrdersList />
                </ProtectedRoute>
              }
            />
            ,
            <Route
              path="/order/:orderId"
              element={
                <ProtectedRoute user={user}>
                  <OrderDetails />
                </ProtectedRoute>
              }
            />
            ,
            <Route
              path="/promos"
              element={
                <ProtectedRoute user={user}>
                  <PromosList />
                </ProtectedRoute>
              }
            />
            ,
            <Route
              path="/promo/:promoId"
              element={
                <ProtectedRoute user={user}>
                  <EditPromoCodes />
                </ProtectedRoute>
              }
            />
            ,
            <Route
              path="/newPromo"
              element={
                <ProtectedRoute user={user}>
                  <NewPromoCodes />
                </ProtectedRoute>
              }
            />
            ,
            <Route
              path="/messages"
              element={
                <ProtectedRoute user={user}>
                  <MessagesList />
                </ProtectedRoute>
              }
            />
            ,
            <Route
              path="/message/:messageId"
              element={
                <ProtectedRoute user={user}>
                  <MessagesDetails />
                </ProtectedRoute>
              }
            />
            ,
            <Route
              path="/login"
              element={
                <PublicRoute user={user}>
                  <Login />
                </PublicRoute>
              }
            />
          </Routes>
        </div>
      </Router>
    </>
  );
}

export default App;
