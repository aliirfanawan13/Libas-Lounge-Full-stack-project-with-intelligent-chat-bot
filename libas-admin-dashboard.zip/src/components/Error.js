import React from "react";

function Error({ text }) {
  return (
    <div style={{ fontSize: "12px", color: "red", marginTop: "2px" }}>
      {text}
    </div>
  );
}

export default Error;
