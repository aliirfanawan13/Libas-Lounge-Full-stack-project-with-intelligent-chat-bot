import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "./featuredInfo.css";
import { ArrowDownward, ArrowUpward } from "@material-ui/icons";
import { getCounts } from "../../redux/thunks/users";
import Loader from "../Loader";

export default function FeaturedInfo() {
  const [data, setData] = useState([]);
  const dispatch = useDispatch();
  const { loading, counts } = useSelector((state) => state.users);

  useEffect(() => {
    dispatch(getCounts());
  }, []);

  useEffect(() => {
    setData(counts);
  }, [counts]);

  console.log(counts);

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <div className="featured">
          <div className="featuredItem">
            <span className="featuredTitle">Total Products</span>
            <div className="featuredMoneyContainer">
              <span className="featuredMoney">{data?.products}</span>
            </div>
          </div>
          <div className="featuredItem">
            <span className="featuredTitle">Total Users</span>
            <div className="featuredMoneyContainer">
              <span className="featuredMoney">{data?.users}</span>
            </div>
          </div>
          <div className="featuredItem">
            <span className="featuredTitle">Orders</span>
            <div className="featuredMoneyContainer">
              <span className="featuredMoney">{data?.orders}</span>
            </div>
          </div>
          <div className="featuredItem">
            <span className="featuredTitle">Promo Codes</span>
            <div className="featuredMoneyContainer">
              <span className="featuredMoney">{data?.promos}</span>
            </div>
          </div>
          <div className="featuredItem">
            <span className="featuredTitle">Messages</span>
            <div className="featuredMoneyContainer">
              <span className="featuredMoney">{data?.messages}</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
