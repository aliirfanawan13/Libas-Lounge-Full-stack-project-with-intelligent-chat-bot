import "./topbar.css";
import { useNavigate } from "react-router-dom";
import { logoutUser } from "../../redux/thunks/users";
import { useDispatch } from "react-redux";

export default function Topbar() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const logoutHandler = () => {
    dispatch(logoutUser({ navigate }));
  };
  return (
    <div className="topbar">
      <div className="topbarWrapper">
        <div className="topLeft">
          <span className="logo">Libas Admin</span>
        </div>
        <div className="topRight">
          <button className="logout-btn" onClick={() => logoutHandler()}>
            Logout
          </button>
        </div>
      </div>
    </div>
  );
}
