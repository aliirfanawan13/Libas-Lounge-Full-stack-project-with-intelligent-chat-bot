import { Category } from "@material-ui/icons";

export const userData = [
  {
    name: "Jan",
    "Active User": 4000,
  },
  {
    name: "Feb",
    "Active User": 3000,
  },
  {
    name: "Mar",
    "Active User": 5000,
  },
  {
    name: "Apr",
    "Active User": 4000,
  },
  {
    name: "May",
    "Active User": 3000,
  },
  {
    name: "Jun",
    "Active User": 2000,
  },
  {
    name: "Jul",
    "Active User": 4000,
  },
  {
    name: "Agu",
    "Active User": 3000,
  },
  {
    name: "Sep",
    "Active User": 4000,
  },
  {
    name: "Oct",
    "Active User": 1000,
  },
  {
    name: "Nov",
    "Active User": 4000,
  },
  {
    name: "Dec",
    "Active User": 3000,
  },
];

export const productData = [
  {
    name: "Jan",
    Sales: 4000,
  },
  {
    name: "Feb",
    Sales: 3000,
  },
  {
    name: "Mar",
    Sales: 5000,
  },
];

export const userRows = [
  {
    id: 1,
    username: "Jon Snow",
    name: "Usman",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    status: "active",
    transaction: "$120.00",
    role: "role",
  },
  {
    id: 2,
    username: "Jon Snow",
    name: "Usman",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    status: "active",
    transaction: "$120.00",
    role: "role",
  },
  {
    id: 3,
    username: "Jon Snow",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    status: "active",
    transaction: "$120.00",
    name: "Usman",
    role: "role",
  },
  {
    id: 4,
    username: "Jon Snow",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    status: "active",
    transaction: "$120.00",
    name: "Usman",
    role: "role",
  },
  {
    id: 5,
    username: "Jon Snow",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    status: "active",
    transaction: "$120.00",
    name: "Usman",
    role: "role",
  },
  {
    id: 6,
    username: "Jon Snow",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    status: "active",
    transaction: "$120.00",
    name: "Usman",
    role: "role",
  },
  {
    id: 7,
    username: "Jon Snow",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    status: "active",
    transaction: "$120.00",
    name: "Usman",
    role: "role",
  },
  {
    id: 8,
    username: "Jon Snow",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    status: "active",
    transaction: "$120.00",
    name: "Usman",
    role: "role",
  },
  {
    id: 9,
    username: "Jon Snow",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    status: "active",
    transaction: "$120.00",
    name: "Usman",
    role: "role",
  },
  {
    id: 10,
    username: "Jon Snow",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    status: "active",
    transaction: "$120.00",
    name: "Usman",
    role: "role",
  },
];

export const productRows = [
  {
    id: 1,
    name: "Apple Airpods",
    img: "https://images.pexels.com/photos/7156886/pexels-photo-7156886.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    stock: 123,
    status: "active",
    price: "$120.00",
    colors: [{ name: "black", code: "#000" }],
    sizes: [
      { size: "S", quantity: 12 },
      { size: "M", quantity: 19 },
    ],
    tags: ["Shirt", "Basic"],
    category: "Formal",
  },
  {
    id: 2,
    name: "Apple Airpods",
    img: "https://images.pexels.com/photos/7156886/pexels-photo-7156886.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    stock: 123,
    status: "active",
    price: "$120.00",
    colors: [{ name: "black", code: "#000" }],
    sizes: [
      { size: "S", quantity: 12 },
      { size: "M", quantity: 19 },
    ],
    tags: ["Shirt", "Basic"],
    category: "Formal",
  },
];

export const promoRows = [
  {
    id: 1,
    code: "ABC172",
    total: 123,
    used: 23,
    remaining: 100,
    percentage: 3,
  },
  {
    id: 2,
    code: "ABC172",
    total: 123,
    used: 23,
    remaining: 100,
    percentage: 3,
  },
  {
    id: 3,
    code: "ABC172",
    total: 123,
    used: 23,
    remaining: 100,
    percentage: 3,
  },
  {
    id: 4,
    code: "ABC172",
    total: 123,
    used: 23,
    remaining: 100,
    percentage: 3,
  },
];

export const messagesRows = [
  {
    id: 1,
    name: "Usman",
    email: "usman@gmail.com",
    subject: "subject",
    message:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum",
  },
  {
    id: 2,
    name: "Arshman",
    email: "arhsman@gmail.com",
    subject: "subject",
    message:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum",
  },
  {
    id: 3,
    name: "Sher",
    email: "sher@gmail.com",
    subject: "subject",
    message:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum",
  },
];

export const orderRows = [
  {
    id: 1,
    productId: "SG234FD",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    address: "house# 2 , modal town , lahore",
    phone: "01200000",
    name: "ali",
    status: "active",
    color: "red",
    quantity: 1,
    size: "L",
    totalAmount: "$120.00",
  },
  {
    id: 2,
    productId: "SG234FD",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    address: "house# 2 , modal town , lahore",
    phone: "01200000",
    name: "ali",
    status: "active",
    color: "red",
    quantity: 1,
    size: "L",
    totalAmount: "$120.00",
  },
  {
    id: 3,
    productId: "SG234FD",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    address: "house# 2 , modal town , lahore",
    phone: "01200000",
    name: "ali",
    status: "active",
    color: "red",
    quantity: 1,
    size: "L",
    totalAmount: "$120.00",
  },
  {
    id: 4,
    productId: "SG234FD",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    address: "house# 2 , modal town , lahore",
    phone: "01200000",
    name: "ali",
    status: "active",
    color: "red",
    quantity: 1,
    size: "L",
    totalAmount: "$120.00",
  },
  {
    id: 5,
    productId: "SG234FD",
    avatar:
      "https://images.pexels.com/photos/1152994/pexels-photo-1152994.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500",
    email: "jon@gmail.com",
    address: "house# 2 , modal town , lahore",
    phone: "01200000",
    name: "ali",
    status: "active",
    color: "red",
    quantity: 1,
    size: "L",
    totalAmount: "$120.00",
  },
];
