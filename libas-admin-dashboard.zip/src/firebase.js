import { initializeApp } from "firebase/app";
import { getFirestore } from "@firebase/firestore";
import { getStorage } from "firebase/storage";
import { getFunctions } from "firebase/functions";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyAQRHXmIqncgYlZ_8iKVyrCTVCNTJoS5hM",
  authDomain: "libas-54738.firebaseapp.com",
  projectId: "libas-54738",
  storageBucket: "libas-54738.appspot.com",
  messagingSenderId: "1070555382397",
  appId: "1:1070555382397:web:9af861e6a60b4a76696714",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const functions = getFunctions(app);
