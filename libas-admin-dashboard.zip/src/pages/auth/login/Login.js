import React, { useState } from "react";
import "./Login.css";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { loginUser } from "../../../redux/thunks/users";
import Error from "../../../components/Error";
import logo from "../../../assets/logo.jpg";

// formik
import { Formik } from "formik";
import * as Yup from "yup";

const validationSchema = Yup.object().shape({
  email: Yup.string().required("Please enter your email"),
  password: Yup.string().required("Please enter your password"),
});

const Login = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { loading, error } = useSelector((state) => state.users);

  return (
    <section>
      <div className="login-page">
        <div className="login-container">
          <div class="logo-img-container">
            <img src={logo} class="log-img" alt="Sample image" />
          </div>
          <div>
            <Formik
              initialValues={{
                email: "",
                password: "",
              }}
              validationSchema={validationSchema}
              onSubmit={(values, { resetForm }) => {
                dispatch(loginUser({ ...values, navigate }));
              }}
            >
              {({
                handleChange,
                handleBlur,
                handleSubmit,
                values,
                touched,
                errors,
              }) => {
                return (
                  <div className="loginForm">
                    <div className="newUserItem">
                      <label>Email address</label>
                      <input
                        type="email"
                        id="form3Example3"
                        name="email"
                        placeholder="Enter a valid email address"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.email}
                      />
                      {errors.email && touched.email && (
                        <Error text={errors.email} />
                      )}
                    </div>

                    <div className="newUserItem">
                      <label class="form-label">Password</label>
                      <input
                        type="password"
                        id="form3Example4"
                        name="password"
                        placeholder="Enter password"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.password}
                      />
                      {errors.password && touched.password && (
                        <Error text={errors.password} />
                      )}
                    </div>
                    {error ? (
                      <div className="alert">
                        Invalid email or password!. Try again.
                      </div>
                    ) : (
                      ""
                    )}
                    <div>
                      {loading ? (
                        <button class="login-btn" disabled>
                          ...loading
                        </button>
                      ) : (
                        <button onClick={handleSubmit} class="login-btn">
                          Login
                        </button>
                      )}
                    </div>
                  </div>
                );
              }}
            </Formik>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Login;
