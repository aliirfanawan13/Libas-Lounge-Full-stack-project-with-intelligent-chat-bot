import FeaturedInfo from "../../components/featuredInfo/FeaturedInfo";
import "./home.css";
import Sidebar from "../../components/sidebar/Sidebar";

export default function Home() {
  return (
    <>
      <div className="home">
        <FeaturedInfo />
      </div>
    </>
  );
}
