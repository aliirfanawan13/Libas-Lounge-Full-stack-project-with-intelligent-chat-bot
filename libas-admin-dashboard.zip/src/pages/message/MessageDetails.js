import { useLocation } from "react-router-dom";

const MessageDetails = () => {
  const location = useLocation();
  const { message } = location.state;

  return (
    <div className="product">
      <div className="productTitleContainer">
        <h1 className="productTitle">Message</h1>
      </div>
      <div className="productTop">
        <div className="productTopRight">
          <div className="productInfoBottom">
            <div className="productInfoItem">
              <span className="productInfoKey">id:</span>
              <span className="productInfoValue">
                {message?.id?.substring(0, 8)}
              </span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">Name:</span>
              <span className="productInfoValue">{message?.name}</span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey" style={{ marginRight: "40px" }}>
                Email
              </span>
              <span className="productInfoValue">{message?.email}</span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">subject:</span>
              <span className="productInfoValue">{message?.subject}</span>
            </div>
            <div className="">
              <span className="productInfoKey" style={{ marginRight: "40px" }}>
                Message:
              </span>
              <span className="productInfoValue">{message?.message}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessageDetails;
