import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "../users/userList/userList.css";
import { DataGrid } from "@material-ui/data-grid";
import { DeleteOutline } from "@material-ui/icons";
import { Link } from "react-router-dom";
import { getMessages, deleteMessage } from "../../redux/thunks/messages";
import Loader from "../../components/Loader";

const MessagesList = () => {
  const [data, setData] = useState([]);
  const dispatch = useDispatch();
  const { loading, messages } = useSelector((state) => state.messages);

  const handleDelete = (id) => {
    dispatch(deleteMessage(id));
    setData(data?.filter((item) => item._id !== id));
  };

  const columns = [
    {
      field: "id",
      headerName: "ID",
      width: 150,
      renderCell: (params) => {
        return (
          <p className="fw-bold mb-0">{params?.row?.id.substring(0, 8)}</p>
        );
      },
    },
    { field: "name", headerName: "Name", width: 250 },
    { field: "email", headerName: "Email", width: 250 },
    { field: "message", headerName: "Message", width: 150 },
    {
      field: "action",
      headerName: "Action",
      width: 150,
      renderCell: (params) => {
        return (
          <>
            <Link
              to={"/message/" + params.row._id}
              state={{ message: params.row }}
            >
              <button className="productListEdit">Details</button>
            </Link>
            <DeleteOutline
              className="productListDelete"
              onClick={() => handleDelete(params.row._id)}
            />
          </>
        );
      },
    },
  ];

  useEffect(() => {
    dispatch(getMessages());
  }, []);

  useEffect(() => {
    setData(messages);
  }, [messages]);

  return (
    <div className="userList">
      {loading ? <Loader /> : ""}
      {messages.length > 0 ? (
        <DataGrid
          rows={data}
          disableSelectionOnClick
          columns={columns}
          pageSize={8}
          checkboxSelection
        />
      ) : (
        ""
      )}
    </div>
  );
};

export default MessagesList;
