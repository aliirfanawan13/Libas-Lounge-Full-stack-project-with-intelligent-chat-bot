import React, { useState } from "react";
import "./OrderDetails.css";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { updateOrder } from "../../redux/thunks/order";
const OrderDetails = () => {
  const [stat, setStat] = useState("completed");
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();
  const { order } = location.state;
  const { loading } = useSelector((state) => state.orders);

  const handleSubmit = () => {
    const values = {
      status: stat,
      id: order._id,
    };
    dispatch(updateOrder({ values, navigate }));
  };

  return (
    <div className="product">
      <div className="productTitleContainer">
        <h1 className="productTitle">Order</h1>
      </div>
      <div className="productTop">
        <div className="productTopRight">
          <div className="productInfoBottom">
            <div className="productInfoItem">
              <span className="productInfoKey">Order id:</span>
              <span className="productInfoValue">
                {order?.id?.substring(0, 8)}
              </span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">Name:</span>
              <span className="productInfoValue">{order.name}</span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">email:</span>
              <span className="productInfoValue">{order.email}</span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">address:</span>
              <span className="productInfoValue">{order.address}</span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">phone:</span>
              <span className="productInfoValue">{order.phone}</span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">Total Bill:</span>
              <span className="productInfoValue">{order.totalAmmount}</span>
            </div>
            <hr style={{ maxWidth: "450px", marginBottom: "10px" }} />
            <div className="productInfoItem">
              <span className="productInfoKey">Products:</span>
            </div>
          </div>
        </div>
      </div>
      {order.products.map((product, index) => {
        return (
          <div
            className="order-details  productTopRight"
            style={{ marginBottom: "30px" }}
          >
            <div style={{ marginBottom: "10px" }}>
              Name
              <span
                style={{
                  marginLeft: "100px",
                  fontWeight: "bold",
                  color: "#5d1b5b",
                }}
              >
                {product.name}
              </span>
            </div>
            <div style={{ marginBottom: "10px" }}>
              {" "}
              Color{" "}
              <span
                style={{
                  marginLeft: "100px",
                  fontWeight: "bold",
                  color: "#5d1b5b",
                }}
              >
                {product.color}
              </span>
            </div>
            <div style={{ marginBottom: "10px" }}>
              Size{""}
              <span
                style={{
                  marginLeft: "100px",
                  fontWeight: "bold",
                  color: "#5d1b5b",
                }}
              >
                {product.size}
              </span>
            </div>
            <div style={{ marginBottom: "10px" }}>
              Quantity{" "}
              <span
                style={{
                  marginLeft: "100px",
                  fontWeight: "bold",
                  color: "#5d1b5b",
                }}
              >
                {product.quantity}
              </span>
            </div>
            <div style={{ marginBottom: "10px" }}>
              Price{" "}
              <span
                style={{
                  marginLeft: "100px",
                  fontWeight: "bold",
                  color: "#5d1b5b",
                }}
              >
                {product.price}
              </span>
            </div>
            <div style={{ marginBottom: "10px" }}>
              ID{" "}
              <span
                style={{
                  marginLeft: "100px",
                  fontWeight: "bold",
                  color: "#5d1b5b",
                }}
              >
                {product.id.substring(0, 8)}
              </span>
            </div>
          </div>
        );
      })}
      <div className="productBottom">
        <div className="productForm">
          <div className="productFormLeft">
            <div className="productInfoItem">
              <label>Status</label>
              <select
                name="inStock"
                id="idStock"
                onChange={(e) => setStat(e.target.value)}
              >
                <option value="completed">Completed</option>
                <option value="active">Active</option>
              </select>
            </div>
          </div>
          <div className="productFormRight">
            {loading ? (
              <button className="addProductButton">Loading...</button>
            ) : (
              <button
                type="submit"
                className="addProductButton"
                onClick={handleSubmit}
              >
                Update
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderDetails;
