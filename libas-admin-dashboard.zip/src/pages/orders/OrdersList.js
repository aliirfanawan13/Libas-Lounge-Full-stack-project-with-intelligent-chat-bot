import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { DataGrid } from "@material-ui/data-grid";
import { DeleteOutline } from "@material-ui/icons";
import { Link } from "react-router-dom";
import "../users/userList/userList.css";
import { getOrders, deleteOrder } from "../../redux/thunks/order";
import Loader from "../../components/Loader";

const OrdersList = () => {
  const [data, setData] = useState([]);
  const dispatch = useDispatch();
  const { loading, orders } = useSelector((state) => state.orders);
  const handleDelete = (id) => {
    dispatch(deleteOrder(id));
    setData(data.filter((item) => item._id !== id));
  };

  const columns = [
    {
      field: "id",
      headerName: "ID",
      width: 150,
      renderCell: (params) => {
        return (
          <p className="fw-bold mb-0">{params?.row?.id.substring(0, 8)}</p>
        );
      },
    },
    {
      field: "name",
      headerName: "Name",
      width: 120,
    },
    {
      field: "phone",
      headerName: "Phone",
      width: 120,
    },
    {
      field: "quantity",
      headerName: "Quantity",
      width: 130,
    },
    {
      field: "totalAmmount",
      headerName: "Amount",
      width: 130,
    },
    {
      field: "status",
      headerName: "Status",
      width: 150,
    },
    {
      field: "action",
      headerName: "Action",
      width: 150,
      renderCell: (params) => {
        return (
          <>
            <Link to={"/order/" + params.row.id} state={{ order: params.row }}>
              <button className="productListEdit">Details</button>
            </Link>
            <DeleteOutline
              className="productListDelete"
              onClick={() => handleDelete(params.row._id)}
            />
          </>
        );
      },
    },
  ];

  useEffect(() => {
    dispatch(getOrders());
  }, []);

  useEffect(() => {
    setData(orders);
  }, [orders]);

  return (
    <div className="userList">
      {loading ? <Loader /> : ""}
      {orders?.length > 0 ? (
        <DataGrid
          rows={data}
          disableSelectionOnClick
          columns={columns}
          pageSize={8}
          checkboxSelection
        />
      ) : (
        ""
      )}
    </div>
  );
};

export default OrdersList;
