import "./newProduct.css";
import { addProduct } from "../../../redux/thunks/product";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
// formik
import { Formik } from "formik";
import * as Yup from "yup";
import Error from "../../../components/Error";

const productvalidationSchema = Yup.object().shape({
  name: Yup.string().required("Please enter product name"),
  price: Yup.string().required("Please enter product price"),
  category: Yup.string().required("Please enter product category"),
});

const colorvalidationSchema = Yup.object().shape({
  color: Yup.string().required("Please enter product color"),
  colorCode: Yup.string().required("Please enter color code"),
});

const sizevalidationSchema = Yup.object().shape({
  size: Yup.string().required("Please enter product size"),
  quantity: Yup.string().required("Please enter size quantity"),
});

export default function NewProduct() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { loading } = useSelector((state) => state.products);
  return (
    <div className="newUser">
      <h1 className="newUserTitle">New Product</h1>
      <Formik
        initialValues={{
          name: "",
          price: "",
          category: "",
          description: "",
          attachments: [],
          tags: "",
          sizes: [],
          colors: [],
        }}
        validationSchema={productvalidationSchema}
        onSubmit={(values, { resetForm }) => {
          console.log(values);
          dispatch(addProduct({ values, navigate }));
        }}
      >
        {({
          handleChange,
          handleBlur,
          handleSubmit,
          setFieldValue,
          values,
          touched,
          errors,
        }) => {
          return (
            <>
              <div className="newUserForm">
                <div className="newUserItem">
                  <label>Name</label>
                  <input
                    type="text"
                    placeholder="name"
                    name="name"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.name}
                  />
                  {errors.name && touched.name && <Error text={errors.name} />}
                </div>
                <div className="newUserItem">
                  <label>Category</label>
                  <input
                    type="text"
                    placeholder="category"
                    name="category"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.category}
                  />
                  {errors.category && touched.category && (
                    <Error text={errors.category} />
                  )}
                </div>
                <div className="newUserItem">
                  <label>
                    Price <small> (PKR)</small>
                  </label>
                  <input
                    type="number"
                    placeholder="price"
                    name="price"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.price}
                  />
                  {errors.price && touched.price && (
                    <Error text={errors.price} />
                  )}
                </div>
                <div className="newUserItem">
                  <label>Tags</label>
                  <input
                    type="text"
                    placeholder="basic, etc"
                    name="tags"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.tags}
                  />
                </div>

                <Formik
                  initialValues={{
                    color: "",
                    colorCode: "",
                  }}
                  validationSchema={colorvalidationSchema}
                  onSubmit={(av, { resetForm }) => {
                    setFieldValue("colors", [
                      ...values.colors,
                      { color: av.color, colorCode: av.colorCode },
                    ]);
                    resetForm();
                  }}
                >
                  {({
                    handleChange,
                    handleBlur,
                    setFieldValue,
                    handleSubmit,
                    values: aValues,
                    touched,
                    errors,
                  }) => {
                    return (
                      <>
                        <div className="newUserItem">
                          <label>Color</label>
                          <input
                            type="text"
                            placeholder="red , white etc"
                            name="color"
                            onChange={handleChange}
                            onBlur={handleBlur}
                            value={aValues.color}
                          />
                          {errors.color && touched.color && (
                            <Error text={errors.color} />
                          )}
                        </div>
                        <div className="newUserItem">
                          <label>Color Code</label>
                          <input
                            type="text"
                            placeholder="#fff, #000 etc"
                            name="colorCode"
                            onChange={handleChange}
                            onBlur={handleBlur}
                            value={aValues.colorCode}
                          />
                          {errors.colorCode && touched.colorCode && (
                            <Error text={errors.colorCode} />
                          )}
                        </div>
                        <button className="addColorBtn" onClick={handleSubmit}>
                          Add Color
                        </button>
                      </>
                    );
                  }}
                </Formik>

                <Formik
                  initialValues={{
                    size: "",
                    quantity: "",
                  }}
                  validationSchema={sizevalidationSchema}
                  onSubmit={(bv, { resetForm }) => {
                    setFieldValue("sizes", [
                      ...values.sizes,
                      { size: bv.size, quantity: bv.quantity },
                    ]);
                    resetForm();
                  }}
                >
                  {({
                    handleChange,
                    handleBlur,
                    handleSubmit,
                    values: bValues,
                    touched,
                    errors,
                  }) => {
                    return (
                      <>
                        <div className="newUserItem">
                          <label>Size</label>
                          <input
                            type="text"
                            placeholder="Size"
                            name="size"
                            onChange={handleChange}
                            onBlur={handleBlur}
                            value={bValues.size}
                          />
                          {errors.size && touched.size && (
                            <Error text={errors.size} />
                          )}
                        </div>
                        <div className="newUserItem">
                          <label>Quantity</label>
                          <input
                            type="text"
                            placeholder="quantity"
                            name="quantity"
                            onChange={handleChange}
                            onBlur={handleBlur}
                            value={bValues.quantity}
                          />
                          {errors.quantity && touched.quantity && (
                            <Error text={errors.quantity} />
                          )}
                        </div>

                        <button className="addSizeBtn" onClick={handleSubmit}>
                          Add Size
                        </button>
                      </>
                    );
                  }}
                </Formik>
                <div className="newUserItem">
                  <label>Description</label>
                  <textarea
                    placeholder="Add product description"
                    name="description"
                    row="8"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.description}
                  />
                </div>
              </div>
              <div style={{ marginTop: "30px" }}>
                <div class="Neon Neon-theme-dragdropbox">
                  <input
                    className="input-style"
                    name="files[]"
                    id="filer_input2"
                    multiple="multiple"
                    type="file"
                    onChange={(e) => {
                      setFieldValue("attachments", [
                        ...values.attachments,
                        e.target.files[0],
                      ]);
                    }}
                  />
                  <div class="Neon-input-dragDrop">
                    <div class="Neon-input-inner">
                      <div class="Neon-input-icon">
                        <i class="fa fa-file-image-o"></i>
                      </div>
                      <div class="Neon-input-text">
                        <h3>Drag&amp;Drop files here</h3>{" "}
                        <span className="span-style">or</span>
                      </div>
                      <a class="Neon-input-choose-btn blue">Browse Files</a>
                    </div>
                  </div>
                </div>
              </div>
              {loading ? (
                <button className="addProductButton">Loading...</button>
              ) : (
                <button
                  type="submit"
                  className="addProductButton"
                  onClick={handleSubmit}
                >
                  Add Product
                </button>
              )}
            </>
          );
        }}
      </Formik>
    </div>
  );
}
