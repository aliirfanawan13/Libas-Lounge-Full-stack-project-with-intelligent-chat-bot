import { Link } from "react-router-dom";
import "./product.css";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { updateProduct } from "../../../redux/thunks/product";
// formik
import { Formik } from "formik";
import * as Yup from "yup";
import Error from "../../../components/Error";

const productvalidationSchema = Yup.object().shape({
  name: Yup.string().required("Please enter product name"),
  price: Yup.string().required("Please enter product price"),
  category: Yup.string().required("Please enter product category"),
});

const colorvalidationSchema = Yup.object().shape({
  color: Yup.string().required("Please enter product color"),
  colorCode: Yup.string().required("Please enter color code"),
});

const sizevalidationSchema = Yup.object().shape({
  size: Yup.string().required("Please enter product size"),
  quantity: Yup.string().required("Please enter size quantity"),
});

export default function Product() {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();
  const { product } = location.state;
  const { loading } = useSelector((state) => state.products);
  return (
    <div className="product">
      <div className="productTitleContainer">
        <h1 className="productTitle">Product</h1>
        <Link to="/newproduct">
          <button className="productAddButton">Create</button>
        </Link>
      </div>
      <div className="productTop">
        <div className="productTopRight">
          <div className="productInfoBottom">
            <div className="productInfoItem">
              <span className="productInfoKey">id:</span>
              <span className="productInfoValue">
                {" "}
                {product?.id?.substring(0, 8)}
              </span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">Name:</span>
              <span className="productInfoValue"> {product?.name}</span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">Tags:</span>
              <span className="productInfoValue"> {product?.tags}</span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">Category:</span>
              <span className="productInfoValue"> {product?.category}</span>
            </div>
            <hr style={{ maxWidth: "450px", marginBottom: "10px" }} />
            <div className="productInfoItem">
              <span className="productInfoKey">Color:</span>
              <span className="productInfoValue">Color Code</span>
            </div>
            {product.colors.map((color) => {
              return (
                <div className="productInfoItem">
                  <span className="productInfoKey">{color?.color}:</span>
                  <span className="productInfoValue"> {color?.colorCode}</span>
                </div>
              );
            })}
            <hr style={{ maxWidth: "450px", marginBottom: "10px" }} />
            <div className="productInfoItem">
              <span className="productInfoKey">Size:</span>
              <span className="productInfoValue">Quantity</span>
            </div>
            {product.sizes.map((size) => {
              return (
                <div className="productInfoItem">
                  <span className="productInfoKey">{size.size}:</span>
                  <span className="productInfoValue"> {size?.quantity}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      <div className="productBottom">
        <Formik
          initialValues={{
            name: product?.name || "",
            price: product?.price || "",
            category: product?.category || "",
            tags: product?.tags || "",
            sizes: product.sizes || [],
            colors: product.colors || [],
            id: product?._id,
          }}
          validationSchema={productvalidationSchema}
          onSubmit={(values, { resetForm }) => {
            dispatch(updateProduct({ values, navigate }));
          }}
        >
          {({
            handleChange,
            handleBlur,
            handleSubmit,
            setFieldValue,
            values,
            touched,
            errors,
          }) => {
            return (
              <>
                <div className="newUserForm">
                  <div className="newUserItem">
                    <label>Name</label>
                    <input
                      type="text"
                      placeholder="name"
                      name="name"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.name}
                    />
                    {errors.name && touched.name && (
                      <Error text={errors.name} />
                    )}
                  </div>
                  <div className="newUserItem">
                    <label>Category</label>
                    <input
                      type="text"
                      placeholder="category"
                      name="category"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.category}
                    />
                    {errors.category && touched.category && (
                      <Error text={errors.category} />
                    )}
                  </div>
                  <div className="newUserItem">
                    <label>
                      Price <small> (PKR)</small>
                    </label>
                    <input
                      type="number"
                      placeholder="price"
                      name="price"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.price}
                    />
                    {errors.price && touched.price && (
                      <Error text={errors.price} />
                    )}
                  </div>
                  <div className="newUserItem">
                    <label>Tags</label>
                    <input
                      type="text"
                      placeholder="basic, etc"
                      name="tags"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.tags}
                    />
                  </div>

                  <Formik
                    initialValues={{
                      color: "",
                      colorCode: "",
                    }}
                    validationSchema={colorvalidationSchema}
                    onSubmit={(av, { resetForm }) => {
                      setFieldValue("colors", [
                        ...values.colors,
                        { color: av.color, colorCode: av.colorCode },
                      ]);
                      resetForm();
                    }}
                  >
                    {({
                      handleChange,
                      handleBlur,
                      setFieldValue,
                      handleSubmit,
                      values: aValues,
                      touched,
                      errors,
                    }) => {
                      return (
                        <>
                          <div className="newUserItem">
                            <label>Color</label>
                            <input
                              type="text"
                              placeholder="red , white etc"
                              name="color"
                              onChange={handleChange}
                              onBlur={handleBlur}
                              value={aValues.color}
                            />
                            {errors.color && touched.color && (
                              <Error text={errors.color} />
                            )}
                          </div>
                          <div className="newUserItem">
                            <label>Color Code</label>
                            <input
                              type="text"
                              placeholder="#fff, #000 etc"
                              name="colorCode"
                              onChange={handleChange}
                              onBlur={handleBlur}
                              value={aValues.colorCode}
                            />
                            {errors.colorCode && touched.colorCode && (
                              <Error text={errors.colorCode} />
                            )}
                          </div>
                          <button
                            className="addColorBtn"
                            onClick={handleSubmit}
                          >
                            Add Color
                          </button>
                        </>
                      );
                    }}
                  </Formik>

                  <Formik
                    initialValues={{
                      size: "",
                      quantity: "",
                    }}
                    validationSchema={sizevalidationSchema}
                    onSubmit={(bv, { resetForm }) => {
                      setFieldValue("sizes", [
                        ...values.sizes,
                        { size: bv.size, quantity: bv.quantity },
                      ]);
                      resetForm();
                    }}
                  >
                    {({
                      handleChange,
                      handleBlur,
                      handleSubmit,
                      values: bValues,
                      touched,
                      errors,
                    }) => {
                      return (
                        <>
                          <div className="newUserItem">
                            <label>Size</label>
                            <input
                              type="text"
                              placeholder="Size"
                              name="size"
                              onChange={handleChange}
                              onBlur={handleBlur}
                              value={bValues.size}
                            />
                            {errors.size && touched.size && (
                              <Error text={errors.size} />
                            )}
                          </div>
                          <div className="newUserItem">
                            <label>Quantity</label>
                            <input
                              type="text"
                              placeholder="quantity"
                              name="quantity"
                              onChange={handleChange}
                              onBlur={handleBlur}
                              value={bValues.quantity}
                            />
                            {errors.quantity && touched.quantity && (
                              <Error text={errors.quantity} />
                            )}
                          </div>

                          <button className="addSizeBtn" onClick={handleSubmit}>
                            Add Size
                          </button>
                        </>
                      );
                    }}
                  </Formik>
                </div>
                {loading ? (
                  <button className="addProductButton">Loading...</button>
                ) : (
                  <button
                    type="submit"
                    className="addProductButton"
                    onClick={handleSubmit}
                  >
                    Update
                  </button>
                )}
              </>
            );
          }}
        </Formik>
      </div>
    </div>
  );
}
