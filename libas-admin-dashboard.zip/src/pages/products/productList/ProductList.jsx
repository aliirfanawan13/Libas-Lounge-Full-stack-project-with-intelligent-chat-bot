import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "./productList.css";
import { DataGrid } from "@material-ui/data-grid";
import { DeleteOutline } from "@material-ui/icons";
import { Link } from "react-router-dom";
import { getProducts, deleteProduct } from "../../../redux/thunks/product";
import Loader from "../../../components/Loader";

export default function ProductList() {
  const [data, setData] = useState([]);
  const dispatch = useDispatch();
  const { loading, products } = useSelector((state) => state.products);
  const handleDelete = (id) => {
    dispatch(deleteProduct(id));
    setData(data.filter((item) => item._id !== id));
  };

  const columns = [
    {
      field: "id",
      headerName: "ID",
      width: 150,
      renderCell: (params) => {
        return (
          <p className="fw-bold mb-0">{params?.row?.id.substring(0, 8)}</p>
        );
      },
    },
    {
      field: "product",
      headerName: "Product",
      width: 200,
      renderCell: (params) => {
        return (
          <div className="productListItem">
            {/* <img className="productListImg" src={params.row.img} alt="" /> */}
            {params.row.name}
          </div>
        );
      },
    },
    {
      field: "category",
      headerName: "Category",
      width: 130,
    },
    {
      field: "price",
      headerName: "Price",
      width: 160,
    },
    {
      field: "action",
      headerName: "Action",
      width: 150,
      renderCell: (params) => {
        return (
          <>
            <Link
              to={"/product/" + params.row.id}
              state={{ product: params.row }}
            >
              <button className="productListEdit">Edit</button>
            </Link>
            <DeleteOutline
              className="productListDelete"
              onClick={() => handleDelete(params.row._id)}
            />
          </>
        );
      },
    },
  ];

  useEffect(() => {
    dispatch(getProducts());
  }, []);

  useEffect(() => {
    setData(products);
  }, [products]);

  return (
    <div className="productList">
      <Link to="/newproduct">
        <button className="productAddButton" style={{ marginBottom: "20px" }}>
          Create
        </button>
      </Link>
      {loading ? <Loader /> : ""}
      {products.length > 0 ? (
        <DataGrid
          rows={data}
          disableSelectionOnClick
          columns={columns}
          pageSize={8}
          checkboxSelection
        />
      ) : (
        ""
      )}
    </div>
  );
}
