import "./CreatePromo.css";
// formik
import { Formik } from "formik";
import * as Yup from "yup";
import Error from "../../components/Error";
import { addPromo } from "../../redux/thunks/promo";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const validationSchema = Yup.object().shape({
  code: Yup.string().required("Please enter promo code"),
  percentage: Yup.number().required("Please enter code percentage"),
  total: Yup.number().required("Please enter number of time code will be used"),
});

const CreatePromos = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { loading } = useSelector((state) => state.promos);
  return (
    <div className="newProduct">
      <h1 className="addProductTitle">New Promo</h1>
      <div className="addProductForm">
        <div className="productFormLeft">
          <Formik
            initialValues={{
              code: "",
              total: "",
              percentage: "",
            }}
            validationSchema={validationSchema}
            onSubmit={(values, { resetForm }) => {
              dispatch(addPromo({ values, navigate }));
            }}
          >
            {({
              handleChange,
              handleBlur,
              handleSubmit,
              values,
              touched,
              errors,
            }) => {
              return (
                <div>
                  <div className="addProductItem">
                    <label>Code</label>
                    <input
                      type="text"
                      placeholder="Code"
                      name="code"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.code}
                    />
                    {errors.code && touched.code && (
                      <Error text={errors.code} />
                    )}
                  </div>

                  <div className="addProductItem">
                    {" "}
                    <label style={{ marginTop: "3px" }}>Percentage</label>
                    <input
                      type="number"
                      placeholder="Percentage"
                      name="percentage"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.percentage}
                    />
                    {errors.percentage && touched.percentage && (
                      <Error text={errors.percentage} />
                    )}
                  </div>

                  <div className="addProductItem">
                    <label style={{ marginTop: "3px" }}>Total</label>
                    <input
                      type="number"
                      placeholder="Total"
                      name="total"
                      code="total"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.total}
                    />
                    {errors.total && touched.total && (
                      <Error text={errors.total} />
                    )}
                  </div>

                  <div style={{ marginTop: "30px" }}>
                    {loading ? (
                      <button className="addProductButton">Loading...</button>
                    ) : (
                      <button
                        className="addProductButton"
                        onClick={handleSubmit}
                      >
                        Update
                      </button>
                    )}
                  </div>
                </div>
              );
            }}
          </Formik>
        </div>
      </div>
    </div>
  );
};

export default CreatePromos;
