import { Link } from "react-router-dom";
// formik
import { Formik } from "formik";
import * as Yup from "yup";
import Error from "../../components/Error";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { updatePromo } from "../../redux/thunks/promo";

const validationSchema = Yup.object().shape({
  code: Yup.string().required("Please enter promo code"),
  percentage: Yup.number().required("Please enter code percentage"),
  total: Yup.number().required("Please enter number of time code will be used"),
});

const EditPromos = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();
  const { promo } = location.state;
  const { loading } = useSelector((state) => state.promos);

  return (
    <div className="product">
      <div className="productTitleContainer">
        <h1 className="productTitle">Promo</h1>
        <Link to="/newPromo">
          <button className="productAddButton">Create</button>
        </Link>
      </div>
      <div className="productTop">
        <div className="productTopRight">
          <div className="productInfoBottom">
            <div className="productInfoItem">
              <span className="productInfoKey">code:</span>
              <span className="productInfoValue">{promo.code}</span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">id:</span>
              <span className="productInfoValue">
                {promo?.id?.substring(0, 8)}
              </span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">Percentage:</span>
              <span className="productInfoValue">{promo.percentage}%</span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">Total:</span>
              <span className="productInfoValue">{promo.total}</span>
            </div>
            <div className="productInfoItem">
              <span className="productInfoKey">Used:</span>
              <span className="productInfoValue">{promo.used}</span>
            </div>
          </div>
        </div>
      </div>
      <div className="productBottom">
        <div className="productForm">
          <div className="productFormLeft">
            <Formik
              initialValues={{
                code: promo?.code || "",
                total: promo?.total || "",
                percentage: promo?.percentage || "",
                id: promo?._id,
              }}
              validationSchema={validationSchema}
              onSubmit={(values, { resetForm }) => {
                dispatch(updatePromo({ values, navigate }));
              }}
            >
              {({
                handleChange,
                handleBlur,
                handleSubmit,
                values,
                touched,
                errors,
              }) => {
                return (
                  <>
                    <label>Code</label>
                    <input
                      type="text"
                      placeholder="Code"
                      name="code"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.code}
                    />
                    {errors.code && touched.code && (
                      <Error text={errors.code} />
                    )}
                    <label style={{ marginTop: "3px" }}>Percentage</label>
                    <input
                      type="number"
                      placeholder="Percentage"
                      name="percentage"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.percentage}
                    />
                    {errors.percentage && touched.percentage && (
                      <Error text={errors.percentage} />
                    )}
                    <label style={{ marginTop: "3px" }}>Total</label>
                    <input
                      type="number"
                      placeholder="Total"
                      name="total"
                      code="total"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.total}
                    />
                    {errors.total && touched.total && (
                      <Error text={errors.total} />
                    )}
                    <div
                      className="productFormRight"
                      style={{ marginTop: "30px" }}
                    >
                      {loading ? (
                        <button className="productButton">Loading...</button>
                      ) : (
                        <button
                          type="submit"
                          className="productButton"
                          onClick={handleSubmit}
                        >
                          Update
                        </button>
                      )}
                    </div>
                  </>
                );
              }}
            </Formik>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditPromos;
