import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "../users/userList/userList.css";
import { DataGrid } from "@material-ui/data-grid";
import { DeleteOutline } from "@material-ui/icons";
import { Link } from "react-router-dom";
import { getPromos, deletePromo } from "../../redux/thunks/promo";
import Loader from "../../components/Loader";

const PromoCodes = () => {
  const [data, setData] = useState([]);
  const dispatch = useDispatch();
  const { loading, promos } = useSelector((state) => state.promos);

  const handleDelete = (id) => {
    dispatch(deletePromo(id));
    setData(data.filter((item) => item._id !== id));
  };
  const columns = [
    {
      field: "id",
      headerName: "ID",
      width: 150,
      renderCell: (params) => {
        return (
          <p className="fw-bold mb-0">{params?.row?.id.substring(0, 8)}</p>
        );
      },
    },
    {
      field: "code",
      headerName: "Code",
      width: 150,
      renderCell: (params) => {
        return <div className="userListUser">{params.row.code}</div>;
      },
    },
    {
      field: "percentage",
      headerName: "Percentage",
      width: 150,
    },
    {
      field: "total",
      headerName: "Total",
      width: 120,
    },
    {
      field: "used",
      headerName: "Used",
      width: 120,
    },
    {
      field: "action",
      headerName: "Action",
      width: 150,
      renderCell: (params) => {
        return (
          <>
            <Link to={"/promo/" + params.row.id} state={{ promo: params.row }}>
              <button className="productListEdit">Edit</button>
            </Link>
            <DeleteOutline
              className="productListDelete"
              onClick={() => handleDelete(params.row._id)}
            />
          </>
        );
      },
    },
  ];

  useEffect(() => {
    dispatch(getPromos());
  }, []);

  useEffect(() => {
    setData(promos);
  }, [promos]);

  return (
    <div className="userList">
      <Link to="/newPromo">
        <button className="productAddButton create-btn">Create</button>
      </Link>
      {loading ? <Loader /> : ""}
      {promos.length > 0 ? (
        <DataGrid
          rows={data}
          disableSelectionOnClick
          columns={columns}
          pageSize={8}
          checkboxSelection
        />
      ) : (
        ""
      )}
    </div>
  );
};

export default PromoCodes;
