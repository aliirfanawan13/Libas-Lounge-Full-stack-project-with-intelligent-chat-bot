import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "./userList.css";
import { DataGrid } from "@material-ui/data-grid";
import { DeleteOutline } from "@material-ui/icons";
import { getUsers, deleteUser } from "../../../redux/thunks/users";
import Loader from "../../../components/Loader";

export default function UserList() {
  const [data, setData] = useState([]);
  const dispatch = useDispatch();
  const { loading, users } = useSelector((state) => state.users);

  const handleDelete = (id) => {
    dispatch(deleteUser(id));
    setData(data.filter((item) => item._id !== id));
  };

  const columns = [
    {
      field: "id",
      headerName: "ID",
      width: 150,
      renderCell: (params) => {
        return (
          <p className="fw-bold mb-0">{params?.row?.id.substring(0, 8)}</p>
        );
      },
    },
    { field: "name", headerName: "Name", width: 250 },
    { field: "email", headerName: "Email", width: 250 },
    { field: "role", headerName: "Role", width: 150 },
    {
      field: "action",
      headerName: "Action",
      width: 150,
      renderCell: (params) => {
        return (
          <DeleteOutline
            className="userListDelete"
            onClick={() => handleDelete(params.row._id)}
          />
        );
      },
    },
  ];

  useEffect(() => {
    dispatch(getUsers());
  }, []);

  useEffect(() => {
    setData(users);
  }, [users]);

  return (
    <div className="userList">
      {loading ? (
        <Loader />
      ) : (
        <DataGrid
          rows={data}
          disableSelectionOnClick
          columns={columns}
          pageSize={8}
          checkboxSelection
        />
      )}
    </div>
  );
}
