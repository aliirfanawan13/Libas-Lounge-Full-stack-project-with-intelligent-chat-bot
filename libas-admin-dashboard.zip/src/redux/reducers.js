import { combineReducers } from "redux";

import users from "./slices/userSlice";
import messages from "./slices/messageSlice";
import promos from "./slices/promoSlice";
import products from "./slices/productSlice";
import orders from "./slices/orderSlice";

export default combineReducers({
  users,
  messages,
  promos,
  products,
  orders,
});
