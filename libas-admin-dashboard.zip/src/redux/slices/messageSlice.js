import { createSlice } from "@reduxjs/toolkit";

import { getMessages, deleteMessage } from "../thunks/messages";

const initialState = {
  messages: [],
  loading: false,
  error: null,
  success: null,
};

const handlePending = (state, action) => {
  state.loading = true;
  state.error = initialState.error;
  state.success = initialState.success;
};
const handleRejected = (state, action) => {
  state.loading = false;
  state.error = action.payload;
};
const handleSuccess = (state, action) => {
  state.loading = false;
  state.success = action.payload;
};
const onGetMessages = (state, action) => {
  state.messages = action.payload;
  state.loading = false;
};
const onDeleteMessage = (state, action) => {
  state.messages = state.messages.filter((msg) => msg._id !== action.payload);
  state.loading = false;
};

const slice = createSlice({
  name: "messages",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getMessages.pending, handlePending)
      .addCase(getMessages.fulfilled, onGetMessages)
      .addCase(getMessages.rejected, handleRejected)

      .addCase(deleteMessage.pending, handlePending)
      .addCase(deleteMessage.fulfilled, onDeleteMessage)
      .addCase(deleteMessage.rejected, handleRejected);
  },
});

export const {} = slice.actions;
export default slice.reducer;
