import { createSlice } from "@reduxjs/toolkit";

import { deleteOrder, getOrders, updateOrder } from "../thunks/order";

const initialState = {
  orders: [],
  loading: false,
  error: null,
  success: null,
};

const handlePending = (state, action) => {
  state.loading = true;
  state.error = initialState.error;
  state.success = initialState.success;
};
const handleRejected = (state, action) => {
  state.loading = false;
  state.error = action.payload;
};
const handleSuccess = (state, action) => {
  state.loading = false;
  state.success = action.payload;
};
const onGetOrders = (state, action) => {
  state.orders = action.payload;
  state.loading = false;
};
const onDeleteOrder = (state, action) => {
  state.orders = state.orders.filter((ord) => ord._id !== action.payload);
  state.loading = false;
};

const onUpdateOrder = (state, action) => {
  state.loading = false;
};

const slice = createSlice({
  name: "orders",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getOrders.pending, handlePending)
      .addCase(getOrders.fulfilled, onGetOrders)
      .addCase(getOrders.rejected, handleRejected)

      .addCase(deleteOrder.pending, handlePending)
      .addCase(deleteOrder.fulfilled, onDeleteOrder)
      .addCase(deleteOrder.rejected, handleRejected)

      .addCase(updateOrder.pending, handlePending)
      .addCase(updateOrder.fulfilled, onUpdateOrder)
      .addCase(updateOrder.rejected, handleRejected);
  },
});

export const {} = slice.actions;
export default slice.reducer;
