import { createSlice } from "@reduxjs/toolkit";

import {
  deleteProduct,
  getProducts,
  updateProduct,
  addProduct,
} from "../thunks/product";

const initialState = {
  products: [],
  loading: false,
  error: null,
  success: null,
};

const handlePending = (state, action) => {
  state.loading = true;
  state.error = initialState.error;
  state.success = initialState.success;
};
const handleRejected = (state, action) => {
  state.loading = false;
  state.error = action.payload;
};
const handleSuccess = (state, action) => {
  state.loading = false;
  state.success = action.payload;
};
const onGetProducts = (state, action) => {
  state.products = action.payload;
  state.loading = false;
};
const onDeleteProduct = (state, action) => {
  state.products = state.products.filter((pro) => pro._id !== action.payload);
  state.loading = false;
};

const onAddProduct = (state, action) => {
  state.loading = false;
};
const onUpdateProduct = (state, action) => {
  state.loading = false;
};

const slice = createSlice({
  name: "products",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getProducts.pending, handlePending)
      .addCase(getProducts.fulfilled, onGetProducts)
      .addCase(getProducts.rejected, handleRejected)

      .addCase(deleteProduct.pending, handlePending)
      .addCase(deleteProduct.fulfilled, onDeleteProduct)
      .addCase(deleteProduct.rejected, handleRejected)

      .addCase(addProduct.pending, handlePending)
      .addCase(addProduct.fulfilled, onAddProduct)
      .addCase(addProduct.rejected, handleRejected)

      .addCase(updateProduct.pending, handlePending)
      .addCase(updateProduct.fulfilled, onUpdateProduct)
      .addCase(updateProduct.rejected, handleRejected);
  },
});

export const {} = slice.actions;
export default slice.reducer;
