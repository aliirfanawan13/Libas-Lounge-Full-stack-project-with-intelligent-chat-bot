import { createSlice } from "@reduxjs/toolkit";

import { deletePromo, getPromos, updatePromo, addPromo } from "../thunks/promo";

const initialState = {
  promos: [],
  loading: false,
  error: null,
  success: null,
};

const handlePending = (state, action) => {
  state.loading = true;
  state.error = initialState.error;
  state.success = initialState.success;
};
const handleRejected = (state, action) => {
  state.loading = false;
  state.error = action.payload;
};
const handleSuccess = (state, action) => {
  state.loading = false;
  state.success = action.payload;
};
const onGetPromos = (state, action) => {
  state.promos = action.payload;
  state.loading = false;
};
const onDeletePromo = (state, action) => {
  state.promos = state.promos.filter((prom) => prom._id !== action.payload);
  state.loading = false;
};

const onAddPromo = (state, action) => {
  state.loading = false;
};
const onUpdatePromo = (state, action) => {
  state.loading = false;
};

const slice = createSlice({
  name: "promos",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getPromos.pending, handlePending)
      .addCase(getPromos.fulfilled, onGetPromos)
      .addCase(getPromos.rejected, handleRejected)

      .addCase(deletePromo.pending, handlePending)
      .addCase(deletePromo.fulfilled, onDeletePromo)
      .addCase(deletePromo.rejected, handleRejected)

      .addCase(addPromo.pending, handlePending)
      .addCase(addPromo.fulfilled, onAddPromo)
      .addCase(addPromo.rejected, handleRejected)

      .addCase(updatePromo.pending, handlePending)
      .addCase(updatePromo.fulfilled, onUpdatePromo)
      .addCase(updatePromo.rejected, handleRejected);
  },
});

export const {} = slice.actions;
export default slice.reducer;
