import { createSlice } from "@reduxjs/toolkit";

import {
  loginUser,
  logoutUser,
  getUsers,
  deleteUser,
  getCounts,
} from "../thunks/users";

const initialState = {
  users: [],
  counts: null,
  user: null,
  loading: false,
  error: null,
  success: null,
};

const handlePending = (state, action) => {
  state.loading = true;
  state.error = initialState.error;
  state.success = initialState.success;
};
const handleRejected = (state, action) => {
  state.loading = false;
  state.error = action.payload;
};
const handleSuccess = (state, action) => {
  state.loading = false;
  state.success = action.payload;
};
const onGetUsers = (state, action) => {
  state.users = action.payload;
  state.loading = false;
};
const onGetCounts = (state, action) => {
  state.counts = action.payload;
  state.loading = false;
};
const onDeleteUser = (state, action) => {
  state.users = state.users.filter((user) => user._id !== action.payload);
  state.loading = false;
};
const onLogin = (state, action) => {
  state.user = action.user;
  state.loading = false;
  state.error = false;
};
const onLogout = (state, action) => {
  state.user = null;
  state.loading = false;
  state.error = false;
};

const slice = createSlice({
  name: "users",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getUsers.pending, handlePending)
      .addCase(getUsers.fulfilled, onGetUsers)
      .addCase(getUsers.rejected, handleRejected)

      .addCase(deleteUser.pending, handlePending)
      .addCase(deleteUser.fulfilled, onDeleteUser)
      .addCase(deleteUser.rejected, handleRejected)

      .addCase(loginUser.pending, handlePending)
      .addCase(loginUser.fulfilled, onLogin)
      .addCase(loginUser.rejected, handleRejected)

      .addCase(logoutUser.pending, handlePending)
      .addCase(logoutUser.fulfilled, onLogout)
      .addCase(logoutUser.rejected, handleRejected)

      .addCase(getCounts.pending, handlePending)
      .addCase(getCounts.fulfilled, onGetCounts)
      .addCase(getCounts.rejected, handleRejected);
  },
});

export const {} = slice.actions;
export default slice.reducer;
