import { createAsyncThunk } from "@reduxjs/toolkit";
import Services from "../../services/services";

export const deleteMessage = createAsyncThunk(
  "messages/deleteMessage",
  async (data, { rejectWithValue }) => {
    const endpoint = "message/delete-by-id";
    console.log("data", data);
    try {
      const msg = await Services.deleteDocument(endpoint, data);
      return data;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const getMessages = createAsyncThunk(
  "messages/getMessages",
  async (data, { rejectWithValue }) => {
    const endpoint = "message/get-all";
    try {
      const msg = await Services.getDocuments(endpoint);
      return msg.msg;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);
