import { createAsyncThunk } from "@reduxjs/toolkit";
import Services from "../../services/services";

export const deleteOrder = createAsyncThunk(
  "orders/deleteOrder",
  async (data, { rejectWithValue }) => {
    const endpoint = "orders/delete-by-id";
    try {
      const pro = await Services.deleteDocument(endpoint, data);
      return data;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const getOrders = createAsyncThunk(
  "orders/getOrders",
  async (data, { rejectWithValue }) => {
    const endpoint = "orders/get-all";
    try {
      const orders = await Services.getDocuments(endpoint);
      console.log(orders.orders);
      return orders.orders;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const updateOrder = createAsyncThunk(
  "orders/updateOrder",
  async (data, { rejectWithValue }) => {
    console.log(data);
    const endpoint = "orders/update";
    try {
      const updatedorder = await Services.updateDocument(endpoint, data.values);
      data.navigate("/orders");
      return updatedorder.updatedorder;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);
