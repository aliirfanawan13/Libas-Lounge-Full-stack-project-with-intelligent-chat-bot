import { createAsyncThunk } from "@reduxjs/toolkit";
import Services from "../../services/services";

export const deletePromo = createAsyncThunk(
  "promos/deletePromo",
  async (data, { rejectWithValue }) => {
    const endpoint = "promo/delete-by-id";
    try {
      const prom = await Services.deleteDocument(endpoint, data);
      return data;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const getPromos = createAsyncThunk(
  "promos/getPromos",
  async (data, { rejectWithValue }) => {
    const endpoint = "promo/get-all";
    try {
      const prom = await Services.getDocuments(endpoint);
      return prom.prom;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const updatePromo = createAsyncThunk(
  "promos/updatePromo",
  async (data, { rejectWithValue }) => {
    const endpoint = "promo/update";
    try {
      const updatedPromo = await Services.updateDocument(endpoint, data.values);
      data.navigate("/promos");
      return updatedPromo.updatedPromo;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const addPromo = createAsyncThunk(
  "promos/addPromo",
  async (data, { rejectWithValue }) => {
    console.log(data);
    const endpoint = "promo/add-new";
    try {
      const promo = await Services.addDocument(endpoint, { ...data.values });
      data.navigate("/promos");
      return;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);
