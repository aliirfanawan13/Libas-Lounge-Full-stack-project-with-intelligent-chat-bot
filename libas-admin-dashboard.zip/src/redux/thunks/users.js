import { createAsyncThunk } from "@reduxjs/toolkit";
import Services from "../../services/services";

export const loginUser = createAsyncThunk(
  "users/loginUser",
  async (data, { rejectWithValue }) => {
    try {
      const user = await Services.signIn(data.email, data.password);
      if (user.role === "user") {
        return rejectWithValue("User not authorized");
      }
      localStorage.setItem("User", JSON.stringify(user));
      data.navigate("/");
      return user;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const deleteUser = createAsyncThunk(
  "users/deleteUser",
  async (data, { rejectWithValue }) => {
    const endpoint = "user/delete";
    console.log(data);
    try {
      const user = await Services.deleteDocument(endpoint, data);
      return data;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const logoutUser = createAsyncThunk(
  "users/logoutUser",
  async (data, { rejectWithValue }) => {
    try {
      localStorage.removeItem("User");
      data.navigate("/login");
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const getUsers = createAsyncThunk(
  "users/getUsers",
  async (data, { rejectWithValue }) => {
    const endpoint = "user/get-all-users";
    try {
      const user = await Services.getDocuments(endpoint);
      console.log("user in thunk", user.users);
      return user.users;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);

export const getCounts = createAsyncThunk(
  "users/getCounts",
  async (data, { rejectWithValue }) => {
    const endpoint = "user/get-documents-count";
    try {
      const counts = await Services.getDocuments(endpoint);
      return counts;
    } catch (err) {
      console.log(err);
      return rejectWithValue(err.message);
    }
  }
);
