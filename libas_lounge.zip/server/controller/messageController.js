import { json } from "express";
import Message from "../models/MessageModal.js";
import { v4 as uuidv4 } from "uuid";

const addNewMessage = async (req, res) => {
  const { name, email, subject, message } = req.body.data;

  const msg = await Message.create({
    name,
    email,
    subject,
    message,
    id: uuidv4(),
  });

  if (msg) {
    res.status(201).json({
      msg,
    });
  } else {
    res.status(400);
    throw new Error("Invalid user data");
  }
};

const getAllMessages = async (req, res) => {
  const msg = await Message.find();
  if (msg) {
    res.json({
      success: true,
      msg: msg,
    });
  } else {
    res.status(404);
    throw new Error("Data not found");
  }
};

const deleteMessages = async (req, res) => {
  const { id } = req.body;
  const query = { _id: id };
  const msg = await Message.findOneAndRemove(query);
  if (msg) {
    res.json({
      success: true,
      msg: msg,
    });
  } else {
    res.status(404),
      json({
        msg: "Data not found",
      });
  }
};

export { addNewMessage, getAllMessages, deleteMessages };
