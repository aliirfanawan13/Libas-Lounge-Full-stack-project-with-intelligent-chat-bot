import Orders from "../models/OrderModal.js";
import { v4 as uuidv4 } from "uuid";

const addNewOrder = async (req, res) => {
  const {
    name,
    address,
    email,
    phone,
    totalAmmount,
    instructions,
    quantity,
    products,
    status,
  } = req.body.data;

  const order = await Orders.create({
    name,
    address,
    email,
    phone,
    status,
    totalAmmount,
    instructions,
    quantity,
    products,
    id: uuidv4(),
  });

  if (order) {
    res.status(201).json({
      order,
    });
  } else {
    res.status(400);
    throw new Error("Promo not added");
  }
};

const getAllOrders = async (req, res) => {
  const orders = await Orders.find();
  if (orders) {
    res.json({
      success: true,
      orders: orders,
    });
  } else {
    res.status(404);
    throw new Error("Data not found");
  }
};

const getOrder = async (req, res) => {
  const { id } = req.body;
  const query = { _id: id };
  const order = await Orders.findById(query);

  if (order) {
    res.json({
      order,
    });
  } else {
    res.status(404);
    throw new Error("Promo not found");
  }
};

const updateOrder = async (req, res) => {
  console.log(req.body);
  const { id } = req.body;
  const query = { _id: id };
  const order = await Orders.findById(query);

  if (order) {
    order.status = req.body?.status || order.status;
    const updatedOrder = await order.save();
    res.json({
      updatedOrder,
    });
  } else {
    res.status(404);
    throw new Error("Promo not found");
  }
};

const deleteOrder = async (req, res) => {
  const { id } = req.body;
  const query = { _id: id };
  const order = await Orders.findOneAndRemove(query);
  if (order) {
    res.json({
      success: true,
      order: order,
    });
  } else {
    res.status(404);
    throw new Error("Data not found");
  }
};

export { addNewOrder, getAllOrders, updateOrder, deleteOrder, getOrder };
