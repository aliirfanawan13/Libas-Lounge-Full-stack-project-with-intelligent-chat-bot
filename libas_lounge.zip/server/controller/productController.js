import Product from "../models/ProductModal.js";
import { v4 as uuidv4 } from "uuid";

const addNewProduct = async (req, res) => {
  const productData = req.body.data;

  const product = await Product.create({
    ...productData,
    id: uuidv4(),
  });

  if (product) {
    res.status(201).json({
      product,
    });
  } else {
    res.status(400);
    throw new Error("Product not added");
  }
};

const getAllProducts = async (req, res) => {
  const products = await Product.find();
  if (products) {
    res.json({
      success: true,
      products: products,
    });
  } else {
    res.status(404);
    throw new Error("Data not found");
  }
};

const getProduct = async (req, res) => {
  const { id } = req.body;
  const query = { _id: id };
  const product = await Product.findById(query);

  if (product) {
    res.json({
      product,
    });
  } else {
    res.status(404);
    throw new Error("Product not found");
  }
};

const updateProduct = async (req, res) => {
  const { id } = req.body;
  const query = { _id: id };
  const product = await Product.findById(query);

  if (product) {
    product.name = req.body?.name || product.name;
    product.videos = req.body?.videos || product.videos;
    product.images = req?.body.images || product.images;
    product.sizes = req.body?.sizes || product.sizes;
    product.colors = req.body?.colors || product.colors;
    product.category = req.body?.category || product.category;
    product.tags = req?.body.tags || product.tags;
    product.SKU = req.body?.SKU || product.SKU;

    const updatedproduct = await product.save();
    res.json({
      updatedproduct,
    });
  } else {
    res.status(404);
    throw new Error("Product not found");
  }
};

const deleteProduct = async (req, res) => {
  const { id } = req.body;
  const query = { _id: id };
  const product = await Product.findOneAndRemove(query);
  if (product) {
    res.json({
      success: true,
      product: product,
    });
  } else {
    res.status(404);
    throw new Error("Data not found");
  }
};

export {
  addNewProduct,
  getAllProducts,
  updateProduct,
  deleteProduct,
  getProduct,
};
