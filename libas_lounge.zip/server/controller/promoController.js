import Promo from "../models/PromoModal.js";
import { v4 as uuidv4 } from "uuid";

const addNewPromo = async (req, res) => {
  const { code, total, percentage } = req.body.data;
  console.log(req.body.data);
  const promo = await Promo.create({
    code,
    used: 0,
    percentage,
    total,
    remaining: total,
    id: uuidv4(),
  });

  if (promo) {
    res.status(201).json({
      promo,
    });
  } else {
    res.status(400);
    throw new Error("Promo not added");
  }
};

const getAllPromos = async (req, res) => {
  const prom = await Promo.find();
  if (prom) {
    res.json({
      success: true,
      prom: prom,
    });
  } else {
    res.status(404);
    throw new Error("Data not found");
  }
};

const getPromo = async (req, res) => {
  const { id } = req.body;
  const query = { _id: id };
  const promo = await Promo.findById(query);

  if (promo) {
    res.json({
      promo,
    });
  } else {
    res.status(404);
    throw new Error("Promo not found");
  }
};

const updatePromo = async (req, res) => {
  const { id } = req.body;
  const query = { _id: id };
  const promo = await Promo.findById(query);

  if (promo) {
    promo.code = req.body?.code || promo.code;
    promo.total = req.body?.total || promo.total;
    promo.remaining = req?.body.remaining || promo.remaining;
    promo.used = req.body?.used || promo.used;
    promo.percentage = req.body?.percentage || promo.percentage;

    const updatedPromo = await promo.save();
    res.json({
      updatedPromo,
    });
  } else {
    res.status(404);
    throw new Error("Promo not found");
  }
};

const deletePromo = async (req, res) => {
  const { id } = req.body;
  const query = { _id: id };
  const prom = await Promo.findOneAndRemove(query);
  if (prom) {
    res.json({
      success: true,
      prom: prom,
    });
  } else {
    res.status(404);
    throw new Error("Data not found");
  }
};

export { addNewPromo, getAllPromos, updatePromo, deletePromo, getPromo };
