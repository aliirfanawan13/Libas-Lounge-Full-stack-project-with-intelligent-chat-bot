import asyncHandler from "express-async-handler";
import User from "../models/UserModal.js";
import Orders from "../models/OrderModal.js";
import Product from "../models/ProductModal.js";
import Promos from "../models/PromoModal.js";
import Message from "../models/MessageModal.js";
import generateToken from "../utils/generateToken.js";
import { v4 as uuidv4 } from "uuid";

// @desc    Auth user & get token
// @route   POST /api/users/auth
// @access  Public
const authUser = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });

  if (user && (await user.matchPassword(password))) {
    generateToken(res, user._id);

    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
    });
  } else {
    res.status(401);
    throw new Error("Invalid email or password");
  }
});

// @desc    Register a new user
// @route   POST /api/users
// @access  Public
const registerUser = asyncHandler(async (req, res) => {
  const { name, role, email, password } = req.body;

  const userExists = await User.findOne({ email });

  if (userExists) {
    res.status(400);
    throw new Error("User already exists");
  }

  const user = await User.create({
    name,
    role,
    email,
    password,
    id: uuidv4(),
  });

  if (user) {
    generateToken(res, user._id);

    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
    });
  } else {
    res.status(400);
    throw new Error("Invalid user data");
  }
});

// @desc    Logout user / clear cookie
// @route   POST /api/users/logout
// @access  Public
const logoutUser = (req, res) => {
  res.cookie("jwt", "", {
    httpOnly: true,
    expires: new Date(0),
  });
  res.status(200).json({ message: "Logged out successfully" });
};

// @desc    Get user profile
// @route   GET /api/users/profile
// @access  Private
const getUserProfile = asyncHandler(async (req, res) => {
  const { id } = req.body;
  const query = { _id: id };
  const user = await User.findById(query);

  if (user) {
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
    });
  } else {
    res.status(404);
    throw new Error("User not found");
  }
});

// @desc    Get all users profile
// @route   GET /api/users/profile
// @access  Private
const getAllUserProfile = asyncHandler(async (req, res) => {
  const users = await User.find();
  if (users) {
    res.json({
      users,
    });
  } else {
    res.status(404);
    throw new Error("No users");
  }
});

// @desc    Update user profile
// @route   PUT /api/users/profile
// @access  Private
const updateUserProfile = asyncHandler(async (req, res) => {
  const { id } = req.body;
  const query = { _id: id };
  const user = await User.findById(query);

  if (user) {
    user.name = req.body.name || user.name;
    user.email = req.body.email || user.email;

    if (req.body.password) {
      user.password = req.body.password;
    }

    const updatedUser = await user.save();

    res.json({
      _id: updatedUser._id,
      name: updatedUser.name,
      email: updatedUser.email,
      role: updatedUser.role,
    });
  } else {
    res.status(404);
    throw new Error("User not found");
  }
});

const deleteUser = async (req, res) => {
  const { id } = req.body;
  console.log(id);
  const query = { _id: id };
  const user = await User.findOneAndRemove(query);
  if (user) {
    res.json({
      success: true,
      user: user,
    });
  } else {
    res.status(404);
    throw new Error("User not found");
  }
};

// @desc    Get all users profile
// @route   GET /api/users/profile
// @access  Private
const getAllDocumentCounts = asyncHandler(async (req, res) => {
  const users = await User.count();
  const orders = await Orders.count();
  const products = await Product.count();
  const promos = await Promos.count();
  const messages = await Message.count();
  var counts = { users, products, promos, orders, messages };
  if (users) {
    res.json(counts);
  } else {
    res.status(404);
    throw new Error("No data");
  }
});

export {
  authUser,
  registerUser,
  logoutUser,
  getUserProfile,
  updateUserProfile,
  getAllUserProfile,
  deleteUser,
  getAllDocumentCounts,
};
