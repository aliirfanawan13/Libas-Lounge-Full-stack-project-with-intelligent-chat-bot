import mongoose from "mongoose";

const ordersSchema = mongoose.Schema(
  {
    name: { type: String },
    address: { type: String },
    status: { type: String },
    email: { type: String },
    phone: { type: String },
    totalAmmount: { type: Number },
    discount: { type: Number },
    instructions: { type: String },
    products: [
      {
        id: { type: String },
        name: { type: String },
        price: { type: Number },
        color: { type: String },
        size: { type: String },
        quantity: { type: Number },
        category: { type: String },
      },
    ],
    id: {
      type: String,
    },
  },
  { timestamps: true }
);

const Orders = mongoose.model("Orders", ordersSchema);

export default Orders;
