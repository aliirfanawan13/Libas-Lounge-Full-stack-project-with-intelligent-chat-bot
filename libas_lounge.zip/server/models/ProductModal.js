import mongoose from "mongoose";

const productSchema = mongoose.Schema(
  {
    name: { type: String },
    price: { type: String },
    attachments: [{ type: String }],
    colors: [
      {
        color: String,
        colorCode: String,
      },
    ],
    sizes: [
      {
        size: String,
        quantity: String,
      },
    ],
    category: { type: String },
    tags: { type: String },
    SKU: { type: String },
    quantity: { type: String },
    images: [{ type: String }],
    videos: [{ type: String }],
    description: { type: String },
    id: {
      type: String,
    },
  },
  { timestamps: true }
);

const Product = mongoose.model("Products", productSchema);

export default Product;
