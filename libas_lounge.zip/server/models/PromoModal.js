import mongoose from "mongoose";

const promosSchema = mongoose.Schema(
  {
    code: { type: String },
    used: { type: Number },
    remaining: { type: Number },
    percentage: { type: Number },
    total: { type: Number },
    id: {
      type: String,
    },
  },
  { timestamps: true }
);

const Promos = mongoose.model("Promos", promosSchema);

export default Promos;
