import express from "express";
const router = express.Router();

import {
  addNewMessage,
  deleteMessages,
  getAllMessages,
} from "../controller/messageController.js";

router.post("/add-new", addNewMessage);
router.get("/get-all", getAllMessages);
router.delete("/delete-by-id", deleteMessages);

export default router;
