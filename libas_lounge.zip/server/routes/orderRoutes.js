import express from "express";
const router = express.Router();

import {
  addNewOrder,
  deleteOrder,
  getAllOrders,
  updateOrder,
} from "../controller/orderController.js";

router.post("/add-new", addNewOrder);
router.get("/get-all", getAllOrders);
router.put("/update", updateOrder);
router.delete("/delete-by-id", deleteOrder);

export default router;
