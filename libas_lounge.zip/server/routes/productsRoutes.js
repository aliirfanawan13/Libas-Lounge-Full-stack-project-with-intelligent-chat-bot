import express from "express";
const router = express.Router();

import {
  addNewProduct,
  deleteProduct,
  getAllProducts,
  getProduct,
  updateProduct,
} from "../controller/productController.js";

router.post("/add-new", addNewProduct);
router.get("/get-product", getProduct);
router.get("/get-all", getAllProducts);
router.put("/update", updateProduct);
router.delete("/delete-by-id", deleteProduct);

export default router;
