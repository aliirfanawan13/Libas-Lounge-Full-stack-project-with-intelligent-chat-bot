import express from "express";
const router = express.Router();

import {
  addNewPromo,
  deletePromo,
  getAllPromos,
  getPromo,
  updatePromo,
} from "../controller/promoController.js";

router.post("/add-new", addNewPromo);
router.get("/get-promo", getPromo);
router.get("/get-all", getAllPromos);
router.put("/update", updatePromo);
router.delete("/delete-by-id", deletePromo);

export default router;
