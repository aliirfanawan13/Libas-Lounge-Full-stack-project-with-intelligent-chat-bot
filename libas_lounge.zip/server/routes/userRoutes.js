import express from "express";
import {
  authUser,
  registerUser,
  logoutUser,
  getUserProfile,
  updateUserProfile,
  getAllUserProfile,
  deleteUser,
  getAllDocumentCounts,
} from "../controller/userController.js";

const router = express.Router();

router.post("/", registerUser);
router.post("/auth", authUser);
router.get("/get-all-users", getAllUserProfile);
router.post("/logout", logoutUser);
router.delete("/delete", deleteUser);
router.get("/get-documents-count", getAllDocumentCounts);
router.route("/profile").get(getUserProfile).put(updateUserProfile);

export default router;
