import express from "express";
import dotenv from "dotenv";
import connectDB from "./config/db.js";
import messagesRoutes from "./routes/messageRoutes.js";
import promoRoutes from "./routes/promoRoutes.js";
import userRoutes from "./routes/userRoutes.js";
import productRoutes from "./routes/productsRoutes.js";
import orderRoutes from "./routes/orderRoutes.js";
import cors from "cors";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

connectDB();

const port = process.env.PORT || 5000;

app.get("/", (req, res) => res.send("server is ready"));

app.use("/api/message", messagesRoutes);
app.use("/api/promo", promoRoutes);
app.use("/api/user", userRoutes);
app.use("/api/product", productRoutes);
app.use("/api/orders", orderRoutes);

app.listen(port, () => console.log(`Server is running on port ${port}`));
